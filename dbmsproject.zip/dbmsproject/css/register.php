<style media="screen">
fieldset{
  background-color: #FFFFFF;
  border: 4px solid #000000;
  color: #000000;
  text-align: centre;
  padding: 30px;
  float: center;
  width: 50%;
  background-image: linear-gradient(70deg , #f7941d 80%, rgb(230, 229, 229) 20%);
}

label{
  color: #000000;
  font-family: sans-serif;
  font-weight: bold;
}

input[type=text]{
  background-color: #FFFFFF;
  color: #000000;
  border: 3px solid #000000;
  font-family: sans-serif;
  font-weight: bold;
  padding: 7px;
  margin: 8px;
}

input[type=password]{
  background-color: #FFFFFF;
  color: #000000;
  border: 3px solid #000000;
  font-family: sans-serif;
  font-weight: bold;
  padding: 7px;
  margin: 8px;
}

input[type=number]{
  background-color: #FFFFFF;
  color: #000000;
  border: 3px solid #000000;
  font-family: sans-serif;
  font-weight: bold;
  padding: 7px;
  margin: 8px;
}

input[type=submit]{
  padding: 8px;
  background-color: #000000;
  color: #FFFFFF;
  text-align: center;
  text-decoration: none;
  display: inline-block;
  font-size: 15px;
  font-weight: bold;
  font-family: Verdana, sans-serif;
  border-radius: 10px;
}

input[type=submit]:hover{
  padding: 8px;
  background-color: #F7941D;
  color: #FFFFFF;
  text-align: center;
  text-decoration: none;
  display: inline-block;
  font-size: 15px;
  font-weight: bold;
  font-family: Verdana, sans-serif;
  border: 3px solid #000000;
  cursor: pointer;
}

input[type=date]{
  background-color: #FFFFFF;
  color: #000000;
  border: 3px solid #000000;
  font-family: sans-serif;
  font-weight: bold;
  padding: 7px;
  margin: 8px;
}

.formtitle{
  color: #FFFFFF;
  font-size: 25px;
  font-family: sans-serif;
  font-weight: bold;
  margin: 8px;
  background-color: #000000;
  padding: 10px;
  text-align: center;
  border-radius: 10px;
}

.registration{
  float: center;
}
</style>
