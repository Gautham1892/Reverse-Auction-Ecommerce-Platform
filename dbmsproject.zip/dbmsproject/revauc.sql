-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jan 09, 2022 at 10:51 AM
-- Server version: 8.0.11
-- PHP Version: 8.0.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `revauc`
--

-- --------------------------------------------------------

--
-- Table structure for table `customer`
--

CREATE TABLE `customer` (
  `sno` int(10) UNSIGNED NOT NULL,
  `c_id` int(11) NOT NULL,
  `name` varchar(200) NOT NULL,
  `email` varchar(150) NOT NULL,
  `password` varchar(150) NOT NULL,
  `dob` date NOT NULL,
  `mobile` bigint(20) DEFAULT NULL,
  `address` varchar(250) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `customer`
--

INSERT INTO `customer` (`sno`, `c_id`, `name`, `email`, `password`, `dob`, `mobile`, `address`) VALUES
(3, 1795450295, 'sadfasd', 'sourav@gmail.com', '123', '2021-12-27', 9445954961, '6/19 BAJANAI KOIL II LANE');

-- --------------------------------------------------------

--
-- Table structure for table `demands`
--

CREATE TABLE `demands` (
  `d_id` int(11) NOT NULL,
  `cust_id` int(11) NOT NULL,
  `lowest_bidder` int(11) DEFAULT NULL,
  `bid_price` int(11) DEFAULT NULL,
  `date` date NOT NULL,
  `h` varchar(20) NOT NULL,
  `m` varchar(20) NOT NULL,
  `s` varchar(20) NOT NULL,
  `p_id` varchar(20) DEFAULT NULL,
  `link` longtext,
  `pro_title` longtext
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `demands`
--

INSERT INTO `demands` (`d_id`, `cust_id`, `lowest_bidder`, `bid_price`, `date`, `h`, `m`, `s`, `p_id`, `link`, `pro_title`) VALUES
(1, 1795450295, 1847203861, 250, '2022-01-09', '13', '40', '0', 'M10', NULL, NULL),
(6, 1795450295, 1847203861, 75000, '2022-01-13', '0', '0', '0', 'M07', NULL, NULL),
(8, 1795450295, NULL, NULL, '2022-01-12', '14', '0', '0', 'M09', NULL, NULL),
(9, 1795450295, NULL, NULL, '2022-01-21', '8', '0', '0', NULL, 'https://www.amazon.com/Samsung-Unlocked-Smartphone-Pro-Grade-SM-G998UZSAXAA/dp/B08N3BYNDN/ref=sr_1_3?crid=ER3YP2J2RLQ9&keywords=samsung&qid=1641719035&sprefix=samsung%2Caps%2C426&sr=8-3&th=1', 'SAMSUNG Galaxy S21 Ultra 5G Factory Unlocked Android Cell Phone 128GB US Version Smartphone Pro-Grade Camera 8K Video 108MP High Res, Phantom Silver');

-- --------------------------------------------------------

--
-- Table structure for table `product`
--

CREATE TABLE `product` (
  `sno` int(11) NOT NULL,
  `p_id` varchar(30) NOT NULL,
  `title` varchar(250) NOT NULL,
  `category` varchar(200) NOT NULL,
  `brand` varchar(200) NOT NULL,
  `model` varchar(200) NOT NULL,
  `ram` varchar(200) NOT NULL,
  `storage` varchar(200) NOT NULL,
  `processor` varchar(200) NOT NULL,
  `os` varchar(200) NOT NULL,
  `colour` varchar(200) NOT NULL,
  `dimension` varchar(200) NOT NULL,
  `image1` varchar(200) NOT NULL,
  `image2` varchar(200) NOT NULL,
  `image3` varchar(200) NOT NULL,
  `image4` varchar(200) NOT NULL,
  `image5` varchar(200) NOT NULL,
  `description` text NOT NULL,
  `detail` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `product`
--

INSERT INTO `product` (`sno`, `p_id`, `title`, `category`, `brand`, `model`, `ram`, `storage`, `processor`, `os`, `colour`, `dimension`, `image1`, `image2`, `image3`, `image4`, `image5`, `description`, `detail`) VALUES
(1, 'M01', 'Jio Phone Black', 'Mobile', 'Generic', 'F320', '512MB', '4GB', 'Generic', 'IOS7', 'Black', '10 x 4 x 4 cm-210 Grams', 'm01_1.jpg', 'm01_2.jpg', 'm01_3.jpg', 'm01_4.jpg', 'm01_5.jpg', 'For Jio Sim 1yr/2yr Subscription Plz Visit nearest Retailer who is very near to you no necessary to visit Jio Store or Jio Digtail.1Yr/2yr All Call Free and Data 2GB per Month', ''),
(2, 'M02', 'KECHAODA K115 with Dual Sim 3.66 cm (1.44\"\") inch QQVGA Phone (Black + Silver)', 'Mobile', 'Kechaoda', 'K115', '512MB', '4GB', 'Generic', 'Symbian 9.1', 'Silver', '9.5 x 4 x 0.9 cm; 100 Grams', 'm02_1.jpg', 'm02_2.jpg', 'm02_3.jpg', 'm02_4.jpg', 'm02_5.jpg', 'DUAL SIM, 1.44 inch Display, Speed Dialing, 800 mAh Removable Battery, 2.5 Hours Talktime and 4.5 Days Standby Time\r\nLanguage Support: Hindi, English, Tamil and Kannada, BLUETOOTH DIALER, VIBRATION, FM with FM Recording\r\nBIS and SAR CERTIFIED, 3.5mm Audio Jack, MP3, AMR, WAV, MP4, 3GP, AVI Format Supported', 'Model Name : K115\r\nWireless Carrier : Unlocked for All Carriers\r\nBrand : KECHAODA\r\nForm factor : Smartphone\r\nMemory Storage Capacity : 32 GB\r\n'),
(3, 'M03', 'Micromax Dual Sim X749, Champagne', 'Mobile', 'Micromax', 'X749', '32MB', '8GB', 'Generic', 'Thread-X', 'Champagne', '70 x 8 x 7 cm; 1 Grams', 'M03_1.jpg', 'M03_2.jpg', 'M03_3.jpg', 'M03_4.jpg', 'M03_5.jpg', 'Wireless FM Radio\r\nDual S\r\n1750 mAh battery\r\nAnti Theft | Auto Call Record Folder Wi\r\nCamera description: Rear\r\nConnector type: Micro USB', 'Model Name : X749\r\nWireless Carrier : Unlocked for All Carriers\r\nBrand : Micromax\r\nForm factor : Bar\r\nMemory Storage Capacity : 8 GB'),
(4, 'M04', 'Redmi 9 Activ (Carbon Black, 4GB RAM, 64GB Storage)', 'Mobile', 'Redmi', '	Redmi 9 Activ', '4GB', '64GB', 'Helio G35', 'MIUI 12', 'Carbon Black', '16.5 x 0.9 x 7.7 cm; 194 Grams', 'M04_1.jfif', 'M04_2.jpg', 'M04_3.jpg', 'M04_4.png', 'M04_5.jpg', 'Processor: Octa-core Helio G35 and upto 2.3GHz clock speed\r\nCamera: 13+2 MP Dual Rear camera with AI portrait| 5 MP front camera\r\nDisplay: 16.58 centimeters (6.53-inch) HD+ display with 720x1600 pixels and 20:9 aspect ratio\r\nBattery: 5000 mAH large battery with 10W wired charger in-box\r\nMemory, Storage & SIM: 6GB RAM | 128GB storage | Dual SIM (nano+nano) + Dedicated SD card slot', 'Model Name : Redmi 9 Activ\r\nWireless Carrier : Unlocked for All Carriers\r\nBrand : Redmi\r\nForm factor : Bar\r\nMemory Storage Capacity : 128 GB\r\n'),
(5, 'M05', 'realme narzo 50i (Carbon Black, 4GB RAM+64GB Storage)', 'Mobile', 'realme', 'RMX3231', '4GB', '64GB', 'Octa-core processor', 'Android 11', 'Carbon Black', '16.5 x 7.6 x 0.9 cm; 195 Grams', 'M05_1.png', 'M05_2.jpg', 'M05_3.jpg', 'M05_4.jpg', 'M05_5.jpg', '4 GB RAM | 64 GB ROM | Expandable Upto 256 GB\r\n16.51 cm (6.5 inch) HD+ Display\r\n8MP Primary Camera | 5MP Front Camera\r\n5000 mAh Battery\r\nOcta-core Processor', 'Model Name : Realme narzo 50i\r\nWireless Carrier : Unlocked for All Carriers\r\nBrand : Realme\r\nForm factor : Bar\r\nMemory Storage Capacity : 64 GB'),
(7, 'M06', 'Tecno Spark 7 (Morpheus Blue, 2GB RAM, 32 GB Storage) - 6000mAh Battery|16 MP Dual Camera| 6.52” Dot Notch Display| Octa Core Processor', 'Mobile', 'Tecno', 'Tecno Spark 7 (2/32GB)', '2GB', '32GB', 'Spreadtrum Octa core SC9863', 'Android 11 (Go Edition), HiOS 7.5', 'Morpheus Blue', '16.5 x 7.6 x 1 cm; 202 Grams', 'M06_1.png', 'M06_2.jpg', 'M06_3.jpg', 'M06_4.jpg', 'M06_5.jpg', '16MP AI dual rear Camera Quad Flash, 8MP Front Camera with dual front flash\r\n6000mAh powerful battery with 40 days standby\r\n6.52HD+Dot Notch Display, 20:9 wide aspect ratio\r\n2GB RAM, 32GB storage expandable up to 256GB, Dual SIM 4G+4G\r\n12 month warranty + One Time Screen Replacement for 100 days, Fast Fingerprint Sensor, Face Unlock', 'Model Name : Tecno Spark 7 (2/32GB)\r\nWireless Carrier : Unlocked for All Carriers\r\nBrand : Tecno\r\nForm factor : Touch\r\nMemory Storage Capacity : 32 GB'),
(8, 'M07', 'Vivo Y1s (Olive Black, 3GB RAM, 32GB Storage)', 'Mobile', 'Vivo', '‎Y1s (3GB RAM, 32GB ROM)', '3GB', '32GB', 'Mediatek', 'Android 10 - Funtouch OS 10.5, Funtouch OS 10.5 based on Android 10', 'Olive Black', '15.5 x 7.5 x 0.8 cm; 161 Grams', 'M07_1.jpg', 'M07_2.jpg', 'M07_3.jpg', 'M07_4.jpg', 'M07_5.jfif', '13MP Rear Camera | 5MP Selfie Camera\r\n15.79cm (6.22\") HD+ Display with 1520 x 720 pixels resolution.\r\nMemory & SIM: 3GB RAM | 32GB internal memory | Dual SIM (nano+nano) dual-standby (4G).\r\nFuntouch OS 10.5 based on Android 10 operating system with MTK P35 octa core processor.\r\n4030mAh battery (Type-C).', 'Model Name : Vivo Y1s\r\nWireless Carrier : Unlocked for All Carriers\r\nBrand : Vivo\r\nForm factor : Bar\r\nMemory Storage Capacity : 32 GB'),
(9, 'M08', 'Nokia C20 Plus, 6.5\" HD+ Screen, 5000 mAh Battery, 3 + 32GB Memory', 'Mobile', 'Nokia', 'Nokia C20 Plus', '3GB', '32GB', 'Unisoc 1.6Ghz Octa-Core SC9863A', 'Android 11 (Go edition)', 'Ocean Blue', '16.5 x 7.6 x 1 cm; 196 Grams', 'M08_1.jpg', 'M08_2.jfif', 'M08_3.jpg', 'M08_4.jpg', 'M08_5.jfif', '1 year replacement guarantee\r\nJio Exclusive up to 10% Price Support. Jio customers can also get additional benefits worth ₹4000\r\n6.5\" (16.51 cms) HD+ V-notch screen\r\n8MP dual rear camera with LED flash and 5MP front camera. With support for Portrait, HDR & Beautification mode\r\n3GB RAM & 32GB internal storage, expandable up to 128GB\r\nUp to 2-days battery life with a 5000 mAh battery\r\nAndroid 11 Go Edition with 2 years of quarterly security updates\r\nPowered by Unisoc 1.6Ghz Octa-Core SC9863A', 'Model Name : Nokia C20 Plus\r\nWireless Carrier : Unlocked for All Carriers\r\nBrand : Nokia\r\nForm factor : Bar\r\nMemory Storage Capacity : 32 GB'),
(10, 'M09', 'Redmi 10 Prime (Phantom Black 4GB RAM 64GB | Helio G88 with extendable RAM Upto 2GB | FHD+ 90Hz Adaptive Sync Display)', 'Mobile', 'Redmi', 'Redmi 10 Prime', '4GB', '64GB', 'MediaTek Helio G88 Octa-core processor with HyperEngine 2.0', 'MIUI 12.5', 'Phantom Black', '16.2 x 1 x 7.6 cm; 192 Grams', 'M09_1.jpg', 'M09_2.jpg', 'M09_3.jpg', 'M09_4.jpg', 'M09_5.jpg', 'Processor: MediaTek Helio G88 Octa-core processor with HyperEngine 2.0 ; Up to 2.0GHz clock speed;\r\nBattery: 6000mAh battery with 18W fast charging support. Upto 9W reverse charging. In box - 22.5W wired charger\r\nDisplay: 6.5 inch FHD+ (2400x1080) Dot display with 90Hz high refresh rate and adaptive refresh rate technology; ; 180Hz touch sampling,\r\nMemory, Storage : 4GB LPDDR4X RAM | 64GB Internal storage', 'Model Name : Redmi 10 Prime\r\nWireless Carrier : Unlocked for All Carriers\r\nBrand : Redmi\r\nForm factor : Bar\r\nMemory Storage Capacity : 64 GB'),
(11, 'M10', 'Samsung Galaxy M12 (Black,6GB RAM, 128GB Storage)', 'Mobile', 'Samsung', 'Galaxy M12', '6GB', '128GB', 'Exynos850 (Octa Core 2.0GH)', 'Android 11, v11.0 operating system,One UI 3.1', 'Black', '1 x 7.6 x 16.4 cm; 221 Grams', 'M10_1.jpg', 'M10_2.jpg', 'M10_3.jpg', 'M10_4.jpg', 'M10_5.jpg', '48MP+5MP+2MP+2MP Quad camera setup- True 48MP (F 2.0) main camera + 5MP (F2.2) Ultra wide camera+ 2MP (F2.4) depth camera + 2MP (2.4) Macro Camera| 8MP (F2.2) front came\r\n6000mAH lithium-ion battery, 1 year manufacturer warranty for device and 6 months manufacturer warranty for in-box accessories including batteries from the date of purchase\r\nAndroid 11, v11.0 operating system,One UI 3.1, with 8nm Power Efficient Exynos850 (Octa Core 2.0GH\r\n16.55 centimeters (6.5-inch) HD+ TFT LCD - infinity v-cut display,90Hz screen refresh rate, HD+ resolution with 720 x 1600 pixels resolution, 269 PPI with 16M color\r\nMemory, Storage & SIM: 4GB RAM | 64GB internal memory expandable up to 1TB| Dual SIM (nano+nano) dual-standby (4G+4', 'Model Name : Galaxy M12\r\nWireless Carrier : Unlocked for All Carriers\r\nBrand : Samsung\r\nForm factor : Bar\r\nMemory Storage Capacity : 64 GB'),
(12, 'M11', 'OPPO A31 (Mystery Black, 6GB RAM, 128GB Storage)', 'Mobile', 'Oppo', 'CPH2015', '6GB', '128GB', 'Mediatek 6765', 'Android', 'Mystery Black', '16.4 x 0.8 x 7.6 cm; 180 Grams', 'M11_1.png', 'M11_2.jpg', 'M11_3.jfif', 'M11_4.jpg', 'M11_5.jpg', '12+2+2MP triple rear camera (12MP main camera+2MP macro lens+2MP depth camera) with Portrait bokeh, macro lens, dazzle color mode, AI beautification | 8MP front camera\r\n16.5 centimeters (6.5-inch) waterdrop multi touch screen with an 89% screen to body ratio | 1600 x 720 pixels resolution, 269 ppi pixel density\r\nMemory, Storage & SIM: 6GB RAM | 128GB internal memory expandable up to 256GB | Dual SIM (nano+nano) dual-standby (4G+4G)\r\nAndroid Pie v9.0 based on ColorOS 6.1 operating system with 2.3GHz Mediatek 6765 octa core processor, IMG GE8320\r\n4230mAH lithium-polymer battery providing talk-time of 45 hours and standby time of 450 hours\r\n1 year manufacturer warranty for device and 6 months manufacturer warranty for in-box accessories including batteries from the date of purchase\r\nBox also includes: USB cable, Sim tray ejecter, pre-applied screen protector and protective case, booklet with warranty card and quick guide. The box does not include earphones\r\n', 'Model Name : CPH2015\r\nWireless Carrier : WhatsApp SIM\r\nBrand : Oppo\r\nForm factor : Smartphone\r\nMemory Storage Capacity : 128 GB'),
(13, 'M12', 'Samsung Galaxy M21 2021 Edition (Charcoal Black, 4GB RAM, 64GB Storage) | FHD+ sAMOLED', 'Mobile', 'Samsung', 'Samsung M21, 2021 Edition', '4GB', '64GB', 'Exynos 9611', 'Android 11.0;OneUI Core3.1', 'Charcoal Black', '0.9 x 7.5 x 15.9 cm; 192 Grams', 'M12_1.jpg', 'M12_2.jpg', 'M12_3.jpg', 'M12_4.jpg', 'M12_5.png', '16.21 centimeters (6.4-inch) Super AMOLED - Infinity U-cut display, FHD+ resolution with 60Hz Refresh rate, protected by Gorilla Glass 3\r\n48MP+8MP+5MP Triple camera setup-48MP (F 2.0) main camera + 8MP (F2.2) Ultra wide camera + 5MP (F2.2) depth camera | 20MP (F2.2) front camera\r\nMonster 6000 mAh Battery | Memory, Storage & SIM: 4GB RAM | 64GB internal memory expandable up to 512GB| SIM 1 + SIM 2 + MicroSD\r\nAndroid v11.0, One UI 3.1 operating system with Exynos 9611 Octa Core Processor 2.3GHz,1.7GHz\r\n6000mAH lithium-ion battery, 1 year manufacturer warranty for device and 6 months manufacturer warranty for in-box accessories including batteries from the date of purchase', 'Model Name : Samsung M21, 2021 Edition\r\nWireless Carrier : Unlocked for All Carriers\r\nBrand : Samsung\r\nForm factor : Bar\r\nMemory Storage Capacity : 64 GB'),
(14, 'M13', 'Redmi Note 10S (Frost White, 6GB RAM, 64GB Storage) - Super Amoled Display | 64 MP Quad Camera | Alexa Built in', 'Mobile', 'Redmi', 'Redmi Note 10S', '6GB', '64GB', 'MediaTek Helio G95 Octa-core; 12nm processor', 'Android 11.0', 'Frost White', '16 x 0.8 x 7.5 cm; 179 Grams', 'M13_1.jpg', 'M13_2.jpg', 'M13_3.jpg', 'M13_4.jpg', 'M13_5.jpg', 'Display: FHD+ (1080x2400) AMOLED Dot display; 16.33 centimeters (6.43 inch); 20:9 aspect ratio\r\nCamera: 64 MP Quad Rear camera with 8MP Ultra-wide, 2MP Macro and Portrait lens| 13 MP Front camera\r\nProcessor: MediaTek Helio G95 Octa-core; 12nm process; Up to 2.05GHz clock speed\r\nBattery: 5000 mAh large battery with 33W fast charger in-box and Type-C connectivity\r\nMemory, Storage & SIM: 6GB RAM | 64GB UFS 2.2 storage expandable up to 512GB with dedicated SD card slot | Dual SIM (nano+nano) dual standby (4G+4G)\r\nAlexa Hands-Free capable: Download the Alexa app on to use Alexa hands-free. Play music, make calls, hear news, open apps, navigate, and more, using just your voice, while on-the-go. Just ask and Alexa will respond instantly.', 'Model Name : Redmi Note 10S\r\nWireless Carrier : Unlocked for All Carriers\r\nBrand : Redmi\r\nForm factor : Bar\r\nMemory Storage Capacity : 64 GB'),
(16, 'M14', 'realme narzo 50A (Oxygen Green, 4GB RAM + 64GB Storage)', 'Mobile', 'realme', 'RMX3430', '4GB', '64GB', 'MediaTek Helio G85 Octa-core Processor', 'Android 11', 'Oxygen Green', '16.5 x 7.6 x 1 cm; 207 Grams', 'M14_1.png', 'M14_2.jpg', 'M14_3.jpg', 'M14_4.jpg', 'M14_5.jpg', 'MediaTek Helio G85 Octa-core Processor\r\n4 GB RAM | 64 GB ROM | Expandable Upto 256 GB\r\n16.51 cm (6.5 inch) HD+ Display\r\n50MP+2MP+2MP Primary Camera | 8MP Front Camera\r\n6000 mAh Battery', 'Model Name : Realme narzo 50A\r\nWireless Carrier : Unlocked for All Carriers\r\nBrand : Realme\r\nForm factor : Bar\r\nMemory Storage Capacity : 4 GB\r\n'),
(18, 'M15', 'Samsung Galaxy M32 (Light Blue, 4GB RAM, 64GB Storage)', 'Mobile', 'Samsung', 'Galaxy M32', '4GB', '64GB', 'MediaTek Helio G80 Octa Core Processor 2GHz,1.8GHz', 'Android v11.0, One UI 3.1', 'Light Blue', '0.9 x 7.4 x 15.9 cm; 196 Grams', 'M15_1.jpg', 'M15_2.jfif', 'M15_3.jpg', 'M15_4.jpg', 'M15_5.jpg', 'Segment Best 16.21 centimeters (6.4-inch) Super AMOLED - Infinity U-cut display, FHD+ resolution with 90Hz Refresh rate, 800 Nits High Brightness Mode, protected by Gorilla Glass 5\r\nVersatile 64MP+8MP+2MP+2MP Quad camera setup-64MP (F 1.8) main camera + 8MP (F2.2) Ultra wide camera+ 2MP (F2.4) depth camera + 2MP (2.4) Macro Camera| 20MP (F2.2) front camera\r\nMonster 6000 mAh Battery | Memory, Storage & SIM: 4GB RAM | 64GB internal memory expandable up to 1TB| SIM 1 + SIM 2 + MicroSD\r\nAndroid v11.0, One UI 3.1 operating system with MediaTek Helio G80 Octa Core Processor 2GHz,1.8GHz\r\n6000mAH lithium-ion battery, 1 year manufacturer warranty for device and 6 months manufacturer warranty for in-box accessories including batteries from the date of purchase', 'Model Name : Galaxy M32\r\nWireless Carrier : Unlocked for All Carriers\r\nBrand : Samsung\r\nForm factor : Bar\r\nMemory Storage Capacity : 64 GB'),
(20, 'M16', 'Vivo Y21 (Diamond Glow, 4GB RAM, 64GB Storage)', 'Mobile', 'Vivo', '‎Vivo Y21', '4GB', '64GB', 'Mediatek Helio P35 Octa core processor', 'Funtouch OS 11.1 operating system based on Android 11', 'Diamond Glow', '16.4 x 7.6 x 0.8 cm; 182 Grams', 'M16_1.jpg', 'M16_2.jpg', 'M16_3.jpg', 'M16_4.jpg', 'M16_5.jpg', '13MP+2MP Rear Camera | 8MP Selfie Camera\r\n16.55cm (6.51\") HD+ Display with 1600 x 720 pixels resolution.\r\nMemory & SIM: 4GB RAM | 64GB internal memory | Dual SIM (nano+nano) dual-standby (4G).\r\nFuntouch OS 11.1 operating system based on Android 11 with Mediatek Helio P35 Octa core processor.\r\n18W fast charging with 5000mAh battery (Type-C).', 'Model Name : Vivo Y21 (Diamond Glow, 4GB RAM, 64GB ROM)\r\nWireless Carrier : Unlocked for All Carriers\r\nBrand : Vivo\r\nForm factor : Bar\r\nMemory Storage Capacity : 64 GB'),
(22, 'M17', 'Tecno POVA 2 (Energy Blue, 4GB RAM, 64GB Storage)| 7000mAh Battery | 48MP Camera | Helio G85', 'Mobile', 'Tecno', 'POVA 2', '4GB', '64GB', 'Helio G85 Gaming Processor Octa-Core ET Engine', 'Android 11', 'Energy Blue', '17.3 x 7.9 x 1 cm; 231 Grams', 'M17_1.jpg', 'M17_2.jpg', 'M17_3.jpg', 'M17_4.jpg', 'M17_5.jpg', '7000mAh Segment First Super Big Battery 46 Days Long Standby\r\n48MP+2MP+2MP+AI Lens Quad Rear Camera Super Night View\r\nHelio G85 Gaming Processor Octa-Core ET Engine\r\n6.95-inch17.65cms FHD+Dot-in Display 180Hz Touch Response Rate\r\n18W Dual IC Type C Charger Side Fingerprint Sensor\r\nConnector type: 3.5mm Jack', 'Model Name : POVA 2\r\nWireless Carrier : Unlocked for All Carriers\r\nBrand : Tecno\r\nForm factor : Smartphone\r\nMemory Storage Capacity : 64 GB'),
(23, 'M18', 'realme 8i (Space Black, 64 GB) (4 GB RAM)', 'Mobile', 'realme', 'RMX3151', '4GB', '64GB', 'MediaTek Helio G96 Processor', 'Android 11', 'Space Black', '16.41 x 7.55 x 0.9 cm; 480 Grams', 'M18_1.jpg', 'M18_2.jpg', 'M18_3.jpg', 'M18_4.jpg', 'M18_5.jpg', '', ''),
(25, 'M19', 'Nokia G20, 48MP Quad Camera, 5050 mAh Battery, 6.5” HD+ Screen, 4 + 64GB Memory', 'Mobile', 'Nokia', 'Nokia G20 4G MTK Helio G35 Octa Core', '4GB', '64GB', 'MediaTek G35 processor', 'Android 11', 'Blue', '16.5 x 7.6 x 0.9 cm; 196 Grams', 'M19_1.jpg', 'M19_2.jpg', 'M19_3.jpg', 'M19_4.jpg', 'M19_5.jpg', '', '');

-- --------------------------------------------------------

--
-- Table structure for table `vendor`
--

CREATE TABLE `vendor` (
  `sno` int(11) NOT NULL,
  `v_id` int(11) NOT NULL,
  `store_name` varchar(200) NOT NULL,
  `owner_name` varchar(200) NOT NULL,
  `email` varchar(150) NOT NULL,
  `password` varchar(150) NOT NULL,
  `gst_no` varchar(150) NOT NULL,
  `phone` bigint(20) DEFAULT NULL,
  `address` varchar(250) NOT NULL,
  `rating` int(11) DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `vendor`
--

INSERT INTO `vendor` (`sno`, `v_id`, `store_name`, `owner_name`, `email`, `password`, `gst_no`, `phone`, `address`, `rating`) VALUES
(1, 1847203861, 'pani puri shop', 'vadakkan', 'vada@gmail.com', '123', '2142142', 9445954961, '6/19 BAJANAI KOIL II LANE', 0);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `customer`
--
ALTER TABLE `customer`
  ADD PRIMARY KEY (`c_id`),
  ADD UNIQUE KEY `KEY` (`sno`),
  ADD UNIQUE KEY `UNIQUE` (`mobile`);

--
-- Indexes for table `demands`
--
ALTER TABLE `demands`
  ADD PRIMARY KEY (`d_id`);

--
-- Indexes for table `product`
--
ALTER TABLE `product`
  ADD PRIMARY KEY (`p_id`),
  ADD KEY `sno` (`sno`);

--
-- Indexes for table `vendor`
--
ALTER TABLE `vendor`
  ADD PRIMARY KEY (`v_id`),
  ADD UNIQUE KEY `KEY` (`sno`),
  ADD UNIQUE KEY `UNIQUE` (`phone`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `customer`
--
ALTER TABLE `customer`
  MODIFY `sno` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `demands`
--
ALTER TABLE `demands`
  MODIFY `d_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `product`
--
ALTER TABLE `product`
  MODIFY `sno` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=26;

--
-- AUTO_INCREMENT for table `vendor`
--
ALTER TABLE `vendor`
  MODIFY `sno` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
