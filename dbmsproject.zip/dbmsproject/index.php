<!DOCTYPE html>
<html lang="zxx">
<head>
	<!-- Meta Tag -->
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name='copyright' content=''>
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
	<!-- Title Tag  -->
    <title>RevAuc</title>
	<!-- Favicon -->
	<link rel="icon" type="image/png" href="images/favicon.png">
	<!-- Web Font -->
	<link href="https://fonts.googleapis.com/css?family=Poppins:200i,300,300i,400,400i,500,500i,600,600i,700,700i,800,800i,900,900i&display=swap" rel="stylesheet">

	<!-- StyleSheet -->

	<!-- Bootstrap -->
	<link rel="stylesheet" href="css/bootstrap.css">
	<!-- Magnific Popup -->
    <link rel="stylesheet" href="css/magnific-popup.min.css">
	<!-- Font Awesome -->
    <link rel="stylesheet" href="css/font-awesome.css">
	<!-- Fancybox -->
	<link rel="stylesheet" href="css/jquery.fancybox.min.css">
	<!-- Themify Icons -->
    <link rel="stylesheet" href="css/themify-icons.css">
	<!-- Nice Select CSS -->
    <link rel="stylesheet" href="css/niceselect.css">
	<!-- Animate CSS -->
    <link rel="stylesheet" href="css/animate.css">
	<!-- Flex Slider CSS -->
    <link rel="stylesheet" href="css/flex-slider.min.css">
	<!-- Owl Carousel -->
    <link rel="stylesheet" href="css/owl-carousel.css">
	<!-- Slicknav -->
    <link rel="stylesheet" href="css/slicknav.min.css">

	<!-- Eshop StyleSheet -->
	<link rel="stylesheet" href="css/reset.css">
	<link rel="stylesheet" href="style.css">
    <link rel="stylesheet" href="css/responsive.css">

	<link href = "css/main.css?v=<?php echo time(); ?>" rel = "stylesheet">


</head>
<body class="js">

	<!-- Preloader -->
	<!--<div class="preloader">
		<div class="preloader-inner">
			<div class="preloader-icon">
				<span></span>
				<span></span>
			</div>
		</div>
	</div> -->
	<!-- End Preloader -->
	<?php
		$con = mysqli_connect("localhost" , "root" , "" , "revauc") ;
		if(mysqli_connect_errno()){
			echo "Failed to connect to MySQL : ".mysqli_error() ;
			die() ;
		}
		session_start() ;
		if($_SERVER['REQUEST_METHOD'] == 'POST'){
			if(isset($_POST['login']) && $_POST['login'] == 'customerLogin'){
				//here complete validation for the customer login is done
				//if the details are okay then some session variables are created
				$mail = $_POST['mail'] ;
				$password = $_POST['pass'] ;
				$query = "SELECT * FROM customer WHERE email = '$mail'" ; //fetching the details of the customer who has the entered email
				$res = mysqli_query($con , $query) ;
				$error_flag = 1 ;
				if(mysqli_num_rows($res) == 0){
					//the entered email ID doesn't exist in the Database
					echo "<script> alert('Entered email does not exist');</script>" ;
					$error_flag = 0 ;
				}
				if($error_flag){
					//this will execute when the entered email is in the database
					while($row = mysqli_fetch_array($res)){
						if($row['password'] == $password){
							// control will come into this block only if the password match
							$_SESSION['name'] = $row['name'] ;
							$_SESSION['id'] = $row['c_id'] ;
							$_SESSION['login_type'] = 'C' ;
						}
						else{
							//when wrong password has been entered
							echo "<script> alert('You have entered wrong password');</script>" ;
						}
					}
				}
			}
			else if(isset($_POST['login']) && $_POST['login'] == 'vendorLogin'){
				//echo "hello , I am in ! <br>" ;
				$mail = $_POST['mail'] ;
				$password = $_POST['pass'] ;
				$query = "SELECT * FROM vendor WHERE email = '$mail'" ;
				$res = mysqli_query($con , $query) ;
				$error_flag = 1 ;
				if(mysqli_num_rows($res) == 0){
					//email doesn't exist in the database
					$error_flag = 0 ;
					echo "<script> alert('Entered email does not exist');</script>" ;
				}
				if($error_flag){
					while($row = mysqli_fetch_array($res)){
						if($password == $row['password']){
							//entered password matches
							$_SESSION['name'] = $row['store_name'] ;
							$_SESSION['id'] = $row['v_id'] ;
							$_SESSION['login_type'] = 'V' ;
							echo '<script language="javascript">';
     						 echo 'window.location.replace("php/auction_house.php")';
      						echo '</script>';
						}
						else{
							echo "<script> alert('You have entered the wrong password');</script>" ;
						}
					}
				}
			}
		}
	?>
	<?php
		if(isset($_SESSION['login_type']) && $_SESSION['login_type'] == 'V'){
			echo '<script language="javascript">';
     						 echo 'window.location.replace("php/auction_house.php")';
      						echo '</script>';
		}
	?>
	<!-- Header -->
	<header class="header shop">
		<!-- Topbar -->
		<div class="topbar">
			<div class="container">
				<div class="row">
					<div class="col-lg-4 col-md-12 col-12">
						<!-- Top Left -->
						<div class="top-left">
							<ul class="list-main">
								<li><i class="ti-headphone-alt"></i> Where sellers bid !</li>
								<!--<li><i class="ti-email"></i> gauthammass2@gmail.com</li>-->
							</ul>
						</div>
						<!--/ End Top Left -->
					</div>
					<div class="col-lg-8 col-md-12 col-12">
						<!-- Top Right -->
						<div class="right-content">
							<ul class="list-main">
								<li><i class="ti-location-pin"></i> Store location</li>
								<li><i class="ti-alarm-clock"></i> <a href="#">Daily deal</a></li>
								<?php
								if(isset($_SESSION['id'])){
								?>
								<li><i class="ti-user"></i> <a href="php/customer.php">Hello <?php echo $_SESSION['name'];?> !</a></li>
								<?php } ?>
								<?php
									if(isset($_SESSION['id'])){
										?>
										<li>
											<form action="templates/logout.php" method = "POST">
												<button type = "submit"  value = "logout" name = "login" class = "navbar-btn">Logout</button>
											</form>
										</li>
										<?php
									}
									else{
								?>
								<li><button type="button" class="navbar-btn" data-bs-toggle="modal" data-bs-target="#vendor-login">Vendor Login</button></li>
								<li><button type="button" class="navbar-btn" data-bs-toggle="modal" data-bs-target="#customer-login">Customer Login</button></li>
								<?php } ?>
							</ul>
						</div>
						<!-- End Top Right -->
					</div>
				</div>
			</div>
		</div>
		<!-- End Topbar -->

		<!-- Header Inner -->
		<div class="header-inner">
			<div class="container">
				<div class="cat-nav-head">
					<div class="row">
						<div class="col-lg-3">
							<div class="all-category">


							</div>
						</div>
						<div class="col-lg-9 col-12">
							<div class="menu-area">
								<!-- Main Menu -->
								<nav class="navbar navbar-expand-lg">
									<div class="navbar-collapse">
										<div class="nav-inner">
											<ul class="nav main-menu menu navbar-nav">
                        <li><img src="images/logo.jfif" alt="RevAuc logo" height="80" width="150"></li>
													<li class="active"><a href="#">Home</a></li>
													<li><a href="php/product_search.php">Products</a></li>
													<li><a href="#">Category<i class="ti-angle-down"></i></a>
														<ul class="dropdown">
															<li><a href="php/product_search.php">Phones</a></li>
															<li><a href="php/product_search.php">Laptops</a></li>
															<li><a href="php/product_search.php">Tvs</a></li>
														</ul>
													</li>

													<li><a href="#">Brands<i class="ti-angle-down"></i></a>
														<ul class="dropdown">
															<li><a href="blog-single-sidebar.html">Apple</a></li>
                              <li><a href="blog-single-sidebar.html">Samsung</a></li>
                              <li><a href="blog-single-sidebar.html">OnePlus</a></li>
                              <li><a href="blog-single-sidebar.html">Vivo</a></li>
                              <li><a href="blog-single-sidebar.html">Oppo</a></li>
                              <li><a href="blog-single-sidebar.html">Redmi</a></li>
                              <li><a href="blog-single-sidebar.html">Realme</a></li>
														</ul>
													</li>
													<li><a href="contact.html">Contact Us</a></li>
												</ul>
										</div>
									</div>
								</nav>
								<!--/ End Main Menu -->
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
		<!--/ End Header Inner -->
	</header>
	<!--/ End Header -->
	<!-- Search bar starts here  -->
	<div class="container searchbar">
		<form action="php/product_search.php">
			<div class="input-group">
				<input type="text" class = "form-control search_bar" name = "search_value" placeholder = "Search for products"  id = "search">
				<div class="input-group-btn">
					<button type = "submit" class  = "btn btn-default" id = "search-btn" name = "search-btn" value = "clicked">
						Search
					</button>
				</div>
			</div>
		</form>
	</div>
	<!-- Search bar ends here  -->
	<!-- Login Modals -->
	<!-- Customer Login modal -->
    <div class="modal fade bd-example-modal-lg " id = "customer-login" tabindex="-1" role="dialog" aria-labelledby="myLargeModalLabel" aria-hidden="true">
		<div class="modal-dialog modal-dialog-centered modal-lg" >
			<div class="modal-content login-modal" >
				<section class = "Form">
					<div class="container">
						<div class="row ">
							<div class="col-lg-5">
								<img src="images/customer.jpeg" class = "img-fluid" style = "height: 100% ; width : 100%" alt="Responsive Image">
							</div>
							<div class="col-lg-7 ml-auto d-flex flex-column  align-items-center">
								<h1 class = "font-weight-bold py-3 login-header">
									RevAuc
								</h1>
								<h3 >Customer-Login</h3>
								<form action = "" method = "POST">
									<div class="form-row">
										<div class="col-lg-12">
											<input type  = "email" placeholder="Enter Email Address" name = "mail" class = "form-control my-3 p-2 login-form" required>
										</div>
									</div>
									<div class="form-row">
										<div class="col-lg-12">
											<input type  = "password" placeholder="Enter Password" name = "pass" class = "form-control my-3 p-2 login-form" required>
										</div>
									</div>
									<div class="form-row">
										<div class="col-lg-12 ">
											<button type = "submit" name = "login" value = "customerLogin" class = "login-btn my-3 p-2">Login</button>
										</div>
									</div>
									<a href = "#" class = "link-secondary login-link">Forgot Password</a>
									<p>Don't have an account ? <a href="php/registration_customer.php" class = "link-secondary login-link">Register Here</a></p>
								</form>
							</div>
						</div>
					</div>
				</section>

			</div>
		</div>
		</div>

    <!-- Vendor Login modal -->
	<div class="modal fade bd-example-modal-lg " id = "vendor-login" tabindex="-1" role="dialog" aria-labelledby="myLargeModalLabel" aria-hidden="true">
		<div class="modal-dialog modal-dialog-centered modal-lg" >
			<div class="modal-content login-modal" >
				<section class = "Form">
					<div class="container">
						<div class="row ">
							<div class="col-lg-5">
								<img src="images/vendor.jpeg" class = "img-fluid" style = "height: 100% ; width : 100%" alt="Responsive Image">
							</div>
							<div class="col-lg-7 ml-auto d-flex flex-column  align-items-center">
								<h1 class = "font-weight-bold py-3 login-header">
									RevAuc
								</h1>
								<h3 >Vendor-Login</h3>
								<form action = "" method = "POST">
									<div class="form-row">
										<div class="col-lg-12">
											<input type  = "email" placeholder="Enter Email Address" name = "mail" class = "form-control my-3 p-2 login-form" required>
										</div>
									</div>
									<div class="form-row">
										<div class="col-lg-12">
											<input type  = "password" placeholder="Enter Password" name = "pass" class = "form-control my-3 p-2 login-form" required>
										</div>
									</div>
									<div class="form-row">
										<div class="col-lg-12 ">
											<button type = "submit" value = "vendorLogin" name = "login" class = "login-btn my-3 p-2">Login</button>
										</div>
									</div>
									<a href = "#" class = "link-secondary login-link">Forgot Password</a>
									<p>Don't have an account ? <a href="php/registration_vendor.php" class = "link-secondary login-link">Register Here</a></p>
								</form>
							</div>
						</div>
					</div>
				</section>

			</div>
		</div>
		</div>

	<!-- Login Modals Ends here-->
	<!-- Slider Area -->
	<section class="hero-slider">
		<!-- Single Slider -->


	<section class="cown-down">
		<div class="section-inner ">
			<div class="container-fluid">
				<div class="row">
					<div class="col-lg-6 col-12 padding-right">
						<div class="image">
							<img src="https://thumbor.forbes.com/thumbor/960x0/https%3A%2F%2Fspecials-images.forbesimg.com%2Fimageserve%2F607adf7dcbfabf4faaa69505%2FiPhone-13--iPhone-13-Pro--iPhone-13-Pro-Max--iPhone-13-Mini--iPhone-13-release-%2F960x0.jpg%3Ffit%3Dscale" alt="#">
						</div>
					</div>
					<div class="col-lg-6 col-12 padding-left">
						<div class="content">
							<div class="heading-block">
								<p class="small-title">Deal of day</p>
								<h3 class="title">Iphone 13 Pro Max</h3>
								<p class="text">Sold by Gautham Enterprices </p>
								<h1 class="price">Rs.90000<s>Rs.120000</s></h1>
								<div class="coming-time">
									<div class="clearfix" data-countdown="2021/02/30"></div>
								</div>
                <form action="php/det.php"  method = "GET">
                    <input type = "hidden" name = "pro" value = "M26">
                    <button type = "submit" class = "more-info price with-discount" style = "padding: 12px ; color: #FFFFFF; font-size: 15px; radius:45 ;">more info</button>
                  </form>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
	</section>


		<!--/ End Single Slider -->
	</section>
	<!--/ End Slider Area -->

	<!-- Start Small Banner  -->
	<section class="small-banner section">
		<div class="container-fluid">
			<div class="row">
				<!-- Single Banner  -->
				<div class="col-lg-4 col-md-6 col-12">
					<div class="single-banner">
						<img src="https://images.news18.com/ibnlive/uploads/2021/09/oneplus_buds_z2_design.jpg?impolicy=website&width=0&height=0" alt="#">
						<div class="content">
							<p>Accessories</p>
							<h3>OnePlues Buds<br> collection</h3>
							<a href="#">Discover Now</a>
						</div>
					</div>
				</div>
				<!-- /End Single Banner  -->
				<!-- Single Banner  -->
				<div class="col-lg-4 col-md-6 col-12">
					<div class="single-banner">
						<img src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQuA1l8FCoVv2QrMNPNKTfejn_FWH6IGuuAkA&usqp=CAU" alt="#">
						<div class="content">
							<p>TV Collectons</p>
							<h3>RealME TV<br> 2021</h3>
							<a href="#">Shop Now</a>
						</div>
					</div>
				</div>
				<!-- /End Single Banner  -->
				<!-- Single Banner  -->
				<div class="col-lg-4 col-12">
					<div class="single-banner tab-height">
						<img src="https://www.cnet.com/a/img/resize/4608f6dad079df7294d5036707c04ce0e0107ffd/hub/2020/07/17/6e3257d5-1652-4528-81d4-09e4c9916af9/oneplus-nord-product.jpg?auto=webp&width=768" alt="#">
						<div class="content">
							<p>Quick Sale</p>
							<h3>OnePlus Nord<br> Up to <span>40%</span> Off</h3>
							<a href="#">Discover Now</a>
						</div>
					</div>
				</div>
				<!-- /End Single Banner  -->
			</div>
		</div>
	</section>
	<!-- End Small Banner -->

	<!-- Start Product Area -->
    <div class="product-area section">

    </div>
	<!-- End Product Area -->

	<!-- Start Midium Banner  -->
	<section class="midium-banner">
		<div class="container">
			<div class="row">
				<!-- Single Banner  -->
				<div class="col-lg-6 col-md-6 col-12">
					<div class="single-banner">
						<img src="https://im.rediff.com/getahead/2019/aug/08samsung-note10-01.jpg" alt="#">
						<div class="content">
							<p>Exclusive Combos</p>
							<h3>Samsung items <br>Up to<span> 50%</span></h3>
							<a href="#">Shop Now</a>
						</div>
					</div>
				</div>
				<!-- /End Single Banner  -->
				<!-- Single Banner  -->
				<div class="col-lg-6 col-md-6 col-12">
					<div class="single-banner">
						<img src="https://s.yimg.com/uu/api/res/1.2/f5wx4zGhAB9BFXeEwWU5Dg--~B/aD02NzU7dz0xMjAwO2FwcGlkPXl0YWNoeW9u/https://media.zenfs.com/en/latestly_557/38645b5b0c94518101fbc920bf2f12b6" alt="#">
						<div class="content">
							<p>Black friday deals</p>
							<h3>mid season <br> up to <span>70%</span></h3>
							<a href="#" class="btn">Shop Now</a>
						</div>
					</div>
				</div>
				<!-- /End Single Banner  -->
			</div>
		</div>
	</section>
	<!-- End Midium Banner -->

	<!-- Start Most Popular
	<div class="product-area most-popular section">
        <div class="container">
            <div class="row">
				<div class="col-12">
					<div class="section-title">
						<h2>Hot Item</h2>
					</div>
				</div>
      </div>--><br><br><br>
            <div class="row">
                <div class="col-12">
                    <div class="owl-carousel popular-slider">
						<!-- Start Single Product -->
						<div class="single-product">
							<div class="product-img">
								<a href="product-details.html">
									<img class="default-img" src="https://via.placeholder.com/550x750" alt="#">
									<img class="hover-img" src="https://via.placeholder.com/550x750" alt="#">
									<span class="out-of-stock">Hot</span>
								</a>
								<div class="button-head">

									<div class="product-action-2">
										<a title="Checkout" href="#">Checkout</a>
									</div>
								</div>
							</div>
							<div class="product-content">
								<h3><a href="product-details.html">H1</a></h3>
								<div class="product-price">
									<span class="old">Rs.6000.00</span>
									<span>Rs.5000.00</span>
								</div>
							</div>
						</div>
						<!-- End Single Product -->
						<!-- Start Single Product -->
						<div class="single-product">
                            <div class="product-img">
                                <a href="product-details.html">
                                    <img class="default-img" src="https://via.placeholder.com/550x750" alt="#">
                                    <img class="hover-img" src="https://via.placeholder.com/550x750" alt="#">
                                </a>
								<div class="button-head">

									<div class="product-action-2">
										<a title="Checkout" href="#">Checkout</a>
									</div>
								</div>
                            </div>
                            <div class="product-content">
                                <h3><a href="product-details.html">H2</a></h3>
                                <div class="product-price">
                                    <span>Rs.5000.00</span>
                                </div>
                            </div>
                        </div>
						<!-- End Single Product -->
						<!-- Start Single Product -->
						<div class="single-product">
                            <div class="product-img">
                                <a href="product-details.html">
                                    <img class="default-img" src="https://via.placeholder.com/550x750" alt="#">
                                    <img class="hover-img" src="https://via.placeholder.com/550x750" alt="#">
									<span class="new">New</span>
                                </a>
								<div class="button-head">

									<div class="product-action-2">
										<a title="Checkout" href="#">Checkout</a>
									</div>
								</div>
                            </div>
                            <div class="product-content">
                                <h3><a href="product-details.html">H3</a></h3>
                                <div class="product-price">
                                    <span>Rs.5000.00</span>
                                </div>
                            </div>
                        </div>
						<!-- End Single Product -->
						<!-- Start Single Product -->
						<div class="single-product">
                            <div class="product-img">
                                <a href="product-details.html">
                                    <img class="default-img" src="https://via.placeholder.com/550x750" alt="#">
                                    <img class="hover-img" src="https://via.placeholder.com/550x750" alt="#">
                                </a>
								<div class="button-head">

									<div class="product-action-2">
										<a title="Checkout" href="#">Checkout</a>
									</div>
								</div>
                            </div>
                            <div class="product-content">
                                <h3><a href="product-details.html">H4</a></h3>
                                <div class="product-price">
                                    <span>Rs.5000.00</span>
                                </div>
                            </div>
                        </div>
						<!-- End Single Product -->
                    </div>
                </div>
            </div>
        </div>
    </div>
	<!-- End Most Popular Area -->

	<!-- Start Shop Home List  -->
	<section class="shop-home-list section">
		<div class="container">
			<div class="row">
				<div class="col-lg-4 col-md-6 col-12">
					<div class="row">
						<div class="col-12">
							<div class="shop-section-title">
								<h1>On sale</h1>
							</div>
						</div>
					</div>
					<!-- Start Single List  -->
					<div class="single-list">
						<div class="row">
							<div class="col-lg-6 col-md-6 col-12">
								<div class="list-image overlay">
									<img src="php/M04_3.jpg" alt="#">
									<!-- <a href="#" class="buy"><i class="fa fa-shopping-bag"></i></a> -->
										<a class = "buy">
									<form action="php/det.php"  method = "GET">
											<input type = "hidden" name = "pro" value = "M04">
											<button type = "submit" class = "shop-btn"><i class="fa fa-shopping-bag"></i></button>
										</form>
										</a>
								</div>
							</div>
							<div class="col-lg-6 col-md-6 col-12 no-padding">
								<div class="content">
									<h4 class="title"><a href="#">Redmi 9 Activ</a></h4>

									<form action="php/det.php"  method = "GET">
											<input type = "hidden" name = "pro" value = "M04">
											<button type = "submit" class = "more-info price with-discount" style = "padding-top : 8px ; padding-bottom:8px ;">more info</button>
										</form>

								</div>
							</div>
						</div>
					</div>
					<!-- End Single List  -->
					<!-- Start Single List  -->
					<div class="single-list">
						<div class="row">
							<div class="col-lg-6 col-md-6 col-12">
								<div class="list-image overlay">
									<img src="php/M05_3.jpg" alt="#">
									<!-- <a href="#" class="buy"><i class="fa fa-shopping-bag"></i></a> -->
										<a class = "buy">
									<form action="php/det.php"  method = "GET">
											<input type = "hidden" name = "pro" value = "M04">
											<button type = "submit" class = "shop-btn"><i class="fa fa-shopping-bag"></i></button>
										</form>
										</a>
								</div>
							</div>
							<div class="col-lg-6 col-md-6 col-12 no-padding">
								<div class="content">
									<h4 class="title"><a href="#">Realme Narzo 50i </a></h4>

									<form action="php/det.php"  method = "GET">
											<input type = "hidden" name = "pro" value = "M05">
											<button type = "submit" class = "more-info price with-discount" style = "padding-top : 8px ; padding-bottom:8px ;">more info</button>
										</form>

								</div>
							</div>
						</div>
					</div>
					<!-- End Single List  -->
					<!-- Start Single List  -->
					<div class="single-list">
						<div class="row">
							<div class="col-lg-6 col-md-6 col-12">
								<div class="list-image overlay">
                  <img src="php/M06_4.jpg" alt="#">
									<!-- <a href="#" class="buy"><i class="fa fa-shopping-bag"></i></a> -->
										<a class = "buy">
									<form action="php/det.php"  method = "GET">
											<input type = "hidden" name = "pro" value = "M06">
											<button type = "submit" class = "shop-btn"><i class="fa fa-shopping-bag"></i></button>
										</form>
										</a>
								</div>
							</div>
							<div class="col-lg-6 col-md-6 col-12 no-padding">
								<div class="content">
									<h5 class="title"><a href="#">Tecno Spark 7</a></h5>
                  <form action="php/det.php"  method = "GET">
											<input type = "hidden" name = "pro" value = "M06">
											<button type = "submit" class = "more-info price with-discount" style = "padding-top : 8px ; padding-bottom:8px ;">more info</button>
										</form>
								</div>
							</div>
						</div>
					</div>
					<!-- End Single List  -->
				</div>
				<div class="col-lg-4 col-md-6 col-12">
					<div class="row">
						<div class="col-12">
							<div class="shop-section-title">
								<h1>Best Seller</h1>
							</div>
						</div>
					</div>
					<!-- Start Single List  -->
					<div class="single-list">
						<div class="row">
							<div class="col-lg-6 col-md-6 col-12">
								<div class="list-image overlay">
                  <img src="php/M07_1.jpg" alt="#">
									<!-- <a href="#" class="buy"><i class="fa fa-shopping-bag"></i></a> -->
										<a class = "buy">
									<form action="php/det.php"  method = "GET">
											<input type = "hidden" name = "pro" value = "M07">
											<button type = "submit" class = "shop-btn"><i class="fa fa-shopping-bag"></i></button>
										</form>
										</a>
								</div>
							</div>
							<div class="col-lg-6 col-md-6 col-12 no-padding">
                <div class="content">
									<h5 class="title"><a href="#">Vivo Y1S</a></h5>
                  <form action="php/det.php"  method = "GET">
											<input type = "hidden" name = "pro" value = "M07">
											<button type = "submit" class = "more-info price with-discount" style = "padding-top : 8px ; padding-bottom:8px ;">more info</button>
										</form>
								</div>
							</div>
						</div>
					</div>
					<!-- End Single List  -->
					<!-- Start Single List  -->
					<div class="single-list">
						<div class="row">
							<div class="col-lg-6 col-md-6 col-12">
								<div class="list-image overlay">
                  <img src="php/M12_1.jpg" alt="#">
									<!-- <a href="#" class="buy"><i class="fa fa-shopping-bag"></i></a> -->
										<a class = "buy">
									<form action="php/det.php"  method = "GET">
											<input type = "hidden" name = "pro" value = "M12">
											<button type = "submit" class = "shop-btn"><i class="fa fa-shopping-bag"></i></button>
										</form>
										</a>
								</div>
							</div>
							<div class="col-lg-6 col-md-6 col-12 no-padding">
								<div class="content">
                  <h5 class="title"><a href="#">Samsung Galaxy M12</a></h5>
                  <form action="php/det.php"  method = "GET">
											<input type = "hidden" name = "pro" value = "M12">
											<button type = "submit" class = "more-info price with-discount" style = "padding-top : 8px ; padding-bottom:8px ;">more info</button>
										</form>
								</div>
							</div>
						</div>
					</div>
					<!-- End Single List  -->
					<!-- Start Single List  -->
					<div class="single-list">
						<div class="row">
							<div class="col-lg-6 col-md-6 col-12">
								<div class="list-image overlay">
                  <img src="php/M09_1.jpg" alt="#">
									<!-- <a href="#" class="buy"><i class="fa fa-shopping-bag"></i></a> -->
										<a class = "buy">
									<form action="php/det.php"  method = "GET">
											<input type = "hidden" name = "pro" value = "M09">
											<button type = "submit" class = "shop-btn"><i class="fa fa-shopping-bag"></i></button>
										</form>
										</a>
								</div>
							</div>
							<div class="col-lg-6 col-md-6 col-12 no-padding">
								<div class="content">
                  <h5 class="title"><a href="#">Redmi 10 Prime</a></h5>
                  <form action="php/det.php"  method = "GET">
											<input type = "hidden" name = "pro" value = "M12">
											<button type = "submit" class = "more-info price with-discount" style = "padding-top : 8px ; padding-bottom:8px ;">more info</button>
										</form>
								</div>
							</div>
						</div>
					</div>
					<!-- End Single List  -->
				</div>
				<div class="col-lg-4 col-md-6 col-12">
					<div class="row">
						<div class="col-12">
							<div class="shop-section-title">
								<h1>Top viewed</h1>
							</div>
						</div>
					</div>
					<!-- Start Single List  -->
					<div class="single-list">
						<div class="row">
							<div class="col-lg-6 col-md-6 col-12">
								<div class="list-image overlay">
                  <img src="php/M15_1.jpg" alt="#">
									<!-- <a href="#" class="buy"><i class="fa fa-shopping-bag"></i></a> -->
										<a class = "buy">
									<form action="php/det.php"  method = "GET">
											<input type = "hidden" name = "pro" value = "M15">
											<button type = "submit" class = "shop-btn"><i class="fa fa-shopping-bag"></i></button>
										</form>
										</a>
								</div>
							</div>
							<div class="col-lg-6 col-md-6 col-12 no-padding">
                <div class="content">
                  <h5 class="title"><a href="#">Samsung Galaxy M32</a></h5>
                  <form action="php/det.php"  method = "GET">
											<input type = "hidden" name = "pro" value = "M12">
											<button type = "submit" class = "more-info price with-discount" style = "padding-top : 8px ; padding-bottom:8px ;">more info</button>
										</form>
								</div>
							</div>
						</div>
					</div>
					<!-- End Single List  -->
					<!-- Start Single List  -->
					<div class="single-list">
						<div class="row">
							<div class="col-lg-6 col-md-6 col-12">
								<div class="list-image overlay">
                  <img src="php/M13_1.jpg" alt="#">
									<!-- <a href="#" class="buy"><i class="fa fa-shopping-bag"></i></a> -->
										<a class = "buy">
									<form action="php/det.php"  method = "GET">
											<input type = "hidden" name = "pro" value = "M13">
											<button type = "submit" class = "shop-btn"><i class="fa fa-shopping-bag"></i></button>
										</form>
										</a>
								</div>
							</div>
							<div class="col-lg-6 col-md-6 col-12 no-padding">
								<div class="content">
                  <h5 class="title"><a href="#">Redmi Note 10S</a></h5>
                  <form action="php/det.php"  method = "GET">
											<input type = "hidden" name = "pro" value = "M12">
											<button type = "submit" class = "more-info price with-discount" style = "padding-top : 8px ; padding-bottom:8px ;">more info</button>
										</form>
								</div>
							</div>
						</div>
					</div>
					<!-- End Single List  -->
					<!-- Start Single List  -->
					<div class="single-list">
						<div class="row">
							<div class="col-lg-6 col-md-6 col-12">
								<div class="list-image overlay">
                  <img src="php/M11_2.jpg" alt="#">
									<!-- <a href="#" class="buy"><i class="fa fa-shopping-bag"></i></a> -->
										<a class = "buy">
									<form action="php/det.php"  method = "GET">
											<input type = "hidden" name = "pro" value = "M11">
											<button type = "submit" class = "shop-btn"><i class="fa fa-shopping-bag"></i></button>
										</form>
										</a>
								</div>
							</div>
							<div class="col-lg-6 col-md-6 col-12 no-padding">
								<div class="content">
                  <h5 class="title"><a href="#">Oppo A31</a></h5>
                  <form action="php/det.php"  method = "GET">
											<input type = "hidden" name = "pro" value = "M11">
											<button type = "submit" class = "more-info price with-discount" style = "padding-top : 8px ; padding-bottom:8px ;">more info</button>
										</form>
								</div>
							</div>
						</div>
					</div>
					<!-- End Single List  -->
				</div>
			</div>
		</div>
	</section>
	<!-- End Shop Home List  -->

	<!-- Start Cowndown Area -->

	<!-- /End Cowndown Area -->



	<!-- Start Shop Services Area -->
	<section class="shop-services section home">
		<div class="container">
			<div class="row">
				<div class="col-lg-3 col-md-6 col-12">
					<!-- Start Single Service -->
					<div class="single-service">
						<i class="ti-rocket"></i>
						<h4>Free shiping</h4>
						<p>Orders over 20000k</p>
					</div>
					<!-- End Single Service -->
				</div>
				<div class="col-lg-3 col-md-6 col-12">
					<!-- Start Single Service -->
					<div class="single-service">
						<i class="ti-reload"></i>
						<h4>Free Return</h4>
						<p>Within 30 days returns</p>
					</div>
					<!-- End Single Service -->
				</div>
				<div class="col-lg-3 col-md-6 col-12">
					<!-- Start Single Service -->
					<div class="single-service">
						<i class="ti-lock"></i>
						<h4>Secure Payment</h4>
						<p>100% secure payment</p>
					</div>
					<!-- End Single Service -->
				</div>
				<div class="col-lg-3 col-md-6 col-12">
					<!-- Start Single Service -->
					<div class="single-service">
						<i class="ti-tag"></i>
						<h4>Best Price</h4>
						<p>Guaranteed price</p>
					</div>
					<!-- End Single Service -->
				</div>
			</div>
		</div>
	</section>
	<!-- End Shop Services Area -->

	<!-- Start Shop Newsletter  -->
	<section class="shop-newsletter section">
		<div class="container">
			<div class="inner-top">
				<div class="row">
					<div class="col-lg-8 offset-lg-2 col-12">
						<!-- Start Newsletter Inner -->
						<div class="inner">
							<h4>Newsletter</h4>
							<p> Subscribe to our newsletter and get <span>10%</span> off your first purchase</p>
							<form action="mail/mail.php" method="get" target="_blank" class="newsletter-inner">
								<input name="EMAIL" placeholder="Your email address" required="" type="email">
								<button class="btn">Subscribe</button>
							</form>
						</div>
						<!-- End Newsletter Inner -->
					</div>
				</div>
			</div>
		</div>
	</section>
	<!-- End Shop Newsletter -->

	<!-- Modal -->


	<!-- Start Footer Area -->
	<footer class="footer">
		<!-- Footer Top -->
		<div class="footer-top section">
			<div class="container">
				<div class="row">
					<div class="col-lg-5 col-md-6 col-12">
						<!-- Single Widget -->
						<div class="single-footer about">
							<div class="logo">
								<a href="index.html"><img src="images/logo.jfif" alt="#"></a>
							</div>
							<p class="text">This page was created as a project by <br>Gautham<br>
							Sourav <br> Jayenth.</p>
							<p class="call">Got Question? Call us 24/7<span><a href="tel:123456789">123 456 789</a></span></p>
						</div>
						<!-- End Single Widget -->
					</div>
					<div class="col-lg-2 col-md-6 col-12">
						<!-- Single Widget -->
						<div class="single-footer links">
							<h4>Information</h4>
							<ul>
								<li><a href="#">About Us</a></li>
								<li><a href="#">Faq</a></li>
								<li><a href="#">Terms & Conditions</a></li>
								<li><a href="#">Contact Us</a></li>
								<li><a href="#">Help</a></li>
							</ul>
						</div>
						<!-- End Single Widget -->
					</div>
					<div class="col-lg-2 col-md-6 col-12">
						<!-- Single Widget -->
						<div class="single-footer links">
							<h4>Customer Service</h4>
							<ul>
								<li><a href="#">Payment Methods</a></li>
								<li><a href="#">Money-back</a></li>
								<li><a href="#">Returns</a></li>
								<li><a href="#">Shipping</a></li>
								<li><a href="#">Privacy Policy</a></li>
							</ul>
						</div>
						<!-- End Single Widget -->
					</div>
					<div class="col-lg-3 col-md-6 col-12">
						<!-- Single Widget -->
						<div class="single-footer social">
							<h4>Get In Touch</h4>
							<!-- Single Widget -->
							<div class="contact">
								<ul>
									<li>M/1, Pushkar Apartments</li>
									<li>Chennai-80</li>
									<li>gauthammass2@gmail.com</li>
									<li>1234567891</li>
								</ul>
							</div>
							<!-- End Single Widget -->
							<ul>
								<li><a href="#"><i class="ti-facebook"></i></a></li>
								<li><a href="#"><i class="ti-twitter"></i></a></li>
								<li><a href="#"><i class="ti-flickr"></i></a></li>
								<li><a href="#"><i class="ti-instagram"></i></a></li>
							</ul>
						</div>
						<!-- End Single Widget -->
					</div>
				</div>
			</div>
		</div>
		<!-- End Footer Top -->
		<div class="copyright">
			<div class="container">
				<div class="inner">
					<div class="row">
						<div class="col-lg-6 col-12">
							<div class="left">
								<p>Copyright © 2022 <a href="http://www.wpthemesgrid.com" target="_blank">dbms project</a>  -  All Rights Reserved.</p>
							</div>
						</div>
						<div class="col-lg-6 col-12">
							<div class="right">
								<img src="images/payments.png" alt="#">
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
	</footer>
	<!-- /End Footer Area -->

	<!-- Jquery -->
    <script src="js/jquery.min.js"></script>
    <script src="js/jquery-migrate-3.0.0.js"></script>
	<script src="js/jquery-ui.min.js"></script>
	<!-- Popper JS -->
	<script src="js/popper.min.js"></script>
	<!-- Bootstrap JS -->
	<script src="js/bootstrap.min.js"></script>
	<!-- Color JS -->
	<script src="js/colors.js"></script>
	<!-- Slicknav JS -->
	<script src="js/slicknav.min.js"></script>
	<!-- Owl Carousel JS -->
	<script src="js/owl-carousel.js"></script>
	<!-- Magnific Popup JS -->
	<script src="js/magnific-popup.js"></script>
	<!-- Waypoints JS -->
	<script src="js/waypoints.min.js"></script>
	<!-- Countdown JS -->
	<script src="js/finalcountdown.min.js"></script>
	<!-- Nice Select JS -->
	<script src="js/nicesellect.js"></script>
	<!-- Flex Slider JS -->
	<script src="js/flex-slider.js"></script>
	<!-- ScrollUp JS -->
	<script src="js/scrollup.js"></script>
	<!-- Onepage Nav JS -->
	<script src="js/onepage-nav.min.js"></script>
	<!-- Easing JS -->
	<script src="js/easing.js"></script>
	<!-- Active JS -->
	<script src="js/active.js"></script>
	<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-ka7Sk0Gln4gmtz2MlQnikT1wXgYsOg+OMhuP+IlRH9sENBO0LRn5q+8nbTov4+1p" crossorigin="anonymous"></script>
</body>
</html>
