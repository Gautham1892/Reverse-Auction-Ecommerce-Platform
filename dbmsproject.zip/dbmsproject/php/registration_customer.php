<?php
session_start() ;
$con = mysqli_connect("localhost","root","","revauc");
if (mysqli_connect_errno()){
  echo "Failed to connect to MySQL: " . mysqli_connect_error();
  die();
  }
if(isset($_POST["nuser_register"])){
  $unamex = mysqli_real_escape_string($con,$_POST["nname"]);
  $emailx = mysqli_real_escape_string($con,$_POST["nemail"]);
  $passwordx = mysqli_real_escape_string($con,$_POST["npassword"]);
  $dobx = mysqli_real_escape_string($con,$_POST["ndob"]);
  $mobilex = mysqli_real_escape_string($con,$_POST["nmobile"]);
  $addressx = mysqli_real_escape_string($con,$_POST["naddress"]);
  $c_idx = mt_rand();
  $sql = "SELECT * FROM customer WHERE email = '$emailx'";
  $result = $con->query($sql);
  if($unamex == '' || $emailx == '' || $passwordx == '' || $dobx == '' || $mobilex == '' || $addressx == ''){
    mysqli_close($con);
	//Checking whether all the fields are filled
    echo '<script language="javascript">';
    echo 'alert("Please fill all mandatory fields")';
    echo '</script>';
  }
  elseif(mysqli_num_rows($result) > 0){
	  //To check whether customer details already exists
    mysqli_close($con);
    echo '<script language="javascript">';
    echo 'alert("User already exists. Try Log In.")';
    echo '</script>';
  }
  else{
	  //To insert new user details in customer table
    $sql1 = "INSERT INTO customer (c_id,name,email,password,dob,mobile,address)
     VALUES ('$c_idx','$unamex','$emailx','$passwordx','$dobx','$mobilex','$addressx');";
    mysqli_query($con,$sql1);
    echo("Error description: " . $con -> error);
    mysqli_close($con);
    echo '<script language="javascript">';
    echo 'window.location.replace("../index.php")';
    echo '</script>';
  }
}
?>

<!DOCTYPE html>
<html lang="zxx">
<head>
	<!-- Meta Tag -->
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name='copyright' content=''>
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
	<!-- Title Tag  -->
    <title>RevAuc</title>
	<!-- Favicon -->
	<link rel="icon" type="image/png" href="images/favicon.png">
	<!-- Web Font -->
	<link href="https://fonts.googleapis.com/css?family=Poppins:200i,300,300i,400,400i,500,500i,600,600i,700,700i,800,800i,900,900i&display=swap" rel="stylesheet">

	<!-- StyleSheet -->

	<!-- Bootstrap -->
	<link rel="stylesheet" href="../css/bootstrap.css">
	<!-- Magnific Popup -->
    <link rel="stylesheet" href="../css/magnific-popup.min.css">
	<!-- Font Awesome -->
    <link rel="stylesheet" href="../css/font-awesome.css">
	<!-- Fancybox -->
	<link rel="stylesheet" href="../css/jquery.fancybox.min.css">
	<!-- Themify Icons -->
    <link rel="stylesheet" href="../css/themify-icons.css">
	<!-- Nice Select CSS -->
    <link rel="stylesheet" href="../css/niceselect.css">
	<!-- Animate CSS -->
    <link rel="stylesheet" href="../css/animate.css">
	<!-- Flex Slider CSS -->
    <link rel="stylesheet" href="../css/flex-slider.min.css">
	<!-- Owl Carousel -->
    <link rel="stylesheet" href="../css/owl-carousel.css">
	<!-- Slicknav -->
    <link rel="stylesheet" href="../css/slicknav.min.css">

	<!-- Eshop StyleSheet -->
	<link rel="stylesheet" href="../css/reset.css">
	<link rel="stylesheet" href="../style.css">
    <link rel="stylesheet" href="../css/responsive.css">

	<link href = "../css/main.css" rel = "stylesheet">
  <?php include '../css/register.php' ?>


</head>
<body class="js">

	<!-- Preloader -->
	<!--<div class="preloader">
		<div class="preloader-inner">
			<div class="preloader-icon">
				<span></span>
				<span></span>
			</div>
		</div>
	</div> -->
	<!-- End Preloader -->


	<!-- Header -->
	<header class="header shop">
		<!-- Topbar -->
		<div class="topbar">
			<div class="container">
				<div class="row">
					<div class="col-lg-4 col-md-12 col-12">
						<!-- Top Left -->
						<div class="top-left">
							<ul class="list-main">
								<li><i class="ti-headphone-alt"></i> 9003666098</li>
								<li><i class="ti-email"></i> gauthammass2@gmail.com</li>
							</ul>
						</div>
						<!--/ End Top Left -->
					</div>
					<div class="col-lg-8 col-md-12 col-12">
						<!-- Top Right -->
						<div class="right-content">
							<ul class="list-main">
								<li><i class="ti-location-pin"></i> Store location</li>
								<li><i class="ti-alarm-clock"></i> <a href="#">Daily deal</a></li>
								<li><i class="ti-user"></i> <a href="#">My account</a></li>
								<li><button type="button" class="navbar-btn" data-bs-toggle="modal" data-bs-target="#vendor-login">Vendor Login</button></li>
								<li><button type="button" class="navbar-btn" data-bs-toggle="modal" data-bs-target="#customer-login">Customer Login</button></li>
							</ul>
						</div>
						<!-- End Top Right -->
					</div>
				</div>
			</div>
		</div>
		<!-- End Topbar -->

		<!-- Header Inner -->
		<div class="header-inner">
			<div class="container">
				<div class="cat-nav-head">
					<div class="row">
						<div class="col-lg-3">
							<div class="all-category">


							</div>
						</div>
						<div class="col-lg-9 col-12">
							<div class="menu-area">
								<!-- Main Menu -->
								<nav class="navbar navbar-expand-lg">
									<div class="navbar-collapse">
										<div class="nav-inner">
											<ul class="nav main-menu menu navbar-nav">
													<li class="active"><a href="../index.php">Home</a></li>
													<li><a href="#">Product<i class="ti-angle-down"></i></a></li>
													<li><a href="#">Service</a></li>
													<li><a href="#">Category<i class="ti-angle-down"></i></a>
														<ul class="dropdown">
															<li><a href="shop-grid.html">Phones</a></li>
															<li><a href="cart.html">Laptops</a></li>
															<li><a href="checkout.html">Tvs</a></li>
														</ul>
													</li>

													<li><a href="#">Brands<i class="ti-angle-down"></i></a>
														<ul class="dropdown">
															<li><a href="blog-single-sidebar.html">Apple</a></li>
														</ul>
													</li>
													<li><a href="contact.html">Contact Us</a></li>
												</ul>
										</div>
									</div>
								</nav>
								<!--/ End Main Menu -->
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
		<!--/ End Header Inner -->
	</header>
	<!--/ End Header -->
	<!-- Login Modals -->
	<!-- Customer Login modal -->
    <div class="modal fade bd-example-modal-lg " id = "customer-login" tabindex="-1" role="dialog" aria-labelledby="myLargeModalLabel" aria-hidden="true">
		<div class="modal-dialog modal-dialog-centered modal-lg" >
			<div class="modal-content login-modal" >
				<section class = "Form">
					<div class="container">
						<div class="row ">
							<div class="col-lg-5">
								<img src="images/customer.jpeg" class = "img-fluid" style = "height: 100% ; width : 100%" alt="Responsive Image">
							</div>
							<div class="col-lg-7 ml-auto d-flex flex-column  align-items-center">
								<h1 class = "font-weight-bold py-3 login-header">
									RevAuc
								</h1>
								<h3 >Customer-Login</h3>
								<form action = "" >
									<div class="form-row">
										<div class="col-lg-12">
											<input type  = "email" placeholder="Enter Email Address" class = "form-control my-3 p-2 login-form" required>
										</div>
									</div>
									<div class="form-row">
										<div class="col-lg-12">
											<input type  = "password" placeholder="Enter Password" class = "form-control my-3 p-2 login-form" required>
										</div>
									</div>
									<div class="form-row">
										<div class="col-lg-12 ">
											<button type = "submit" class = "login-btn my-3 p-2">Login</button>
										</div>
									</div>
									<a href = "#" class = "link-secondary">Forgot Password</a>
									<p>Don't have an account ? <a href="registration_customer.php" class = "link-secondary">Register Here</a></p>
								</form>
							</div>
						</div>
					</div>
				</section>

			</div>
		</div>
		</div>

    <!-- Vendor Login modal -->
	<div class="modal fade bd-example-modal-lg " id = "vendor-login" tabindex="-1" role="dialog" aria-labelledby="myLargeModalLabel" aria-hidden="true">
		<div class="modal-dialog modal-dialog-centered modal-lg" >
			<div class="modal-content login-modal" >
				<section class = "Form">
					<div class="container">
						<div class="row ">
							<div class="col-lg-5">
								<img src="images/vendor.jpeg" class = "img-fluid" style = "height: 100% ; width : 100%" alt="Responsive Image">
							</div>
							<div class="col-lg-7 ml-auto d-flex flex-column  align-items-center">
								<h1 class = "font-weight-bold py-3 login-header">
									RevAuc
								</h1>
								<h3 >Vendor-Login</h3>
								<form action = "" >
									<div class="form-row">
										<div class="col-lg-12">
											<input type  = "email" placeholder="Enter Email Address" class = "form-control my-3 p-2 login-form" required>
										</div>
									</div>
									<div class="form-row">
										<div class="col-lg-12">
											<input type  = "password" placeholder="Enter Password" class = "form-control my-3 p-2 login-form" required>
										</div>
									</div>
									<div class="form-row">
										<div class="col-lg-12 ">
											<button type = "submit" class = "login-btn my-3 p-2">Login</button>
										</div>
									</div>
									<a href = "#" class = "link-secondary">Forgot Password</a>
									<p>Don't have an account ? <a href="registration_vendor.php" class = "link-secondary">Register Here</a></p>
								</form>
							</div>
						</div>
					</div>
				</section>

			</div>
		</div>
  </div><br><br>

	<!-- Login Modals Ends here-->

  <img src="../images/customer_reg.png" alt="" width="50%" style="float:right">

  <?php

		if(isset($_SESSION['id'])){
			echo '<script language="javascript">';
      		echo 'window.location.replace("../index.php")';
      		echo '</script>';
		}
  ?>

  <!-- Form that allows new customers to enter their details -->
      <form class="" action="registration_customer.php" method="post">
        <fieldset>
          <p class="formtitle">Registration for new customers !</p><br>
          <label for="nname">Name         :  </label>
          <input type="text" id="nname" name="nname" placeholder="Enter your name..."><br><br><br>
          <label for="nemail">E-Mail      :  </label>
          <input type="text" id="nemail" name="nemail" placeholder="Enter your E-Mail ID..."><br><br><br>
          <label for="npassword">Password :  </label>
          <input type="password" id="npassword" name="npassword" placeholder="Enter your password..."><br><br><br>
          <label for="ndob">Date of birth      :  </label>
          <input type="date" id="ndob" name="ndob" placeholder="Enter your DOB..."><br><br><br>
          <label for="nmobile">Mobile No. :  </label>
          <input type="text" id="nmobile" name="nmobile" maxlength="10" placeholder="Enter your mobile no."><br><br><br>
          <label for="naddress">Address   :  </label>
          <input type="text" id="naddress" name="naddress" placeholder="Enter your address..."><br><br><br>
          <input type="submit" id="nuser_register" name="nuser_register" value="REGISTER">
        </fieldset>
      </form><br><br><br>

<!-- Registration form ends here -->

	<!-- Start Footer Area -->
	<footer class="footer">
		<!-- Footer Top -->
		<div class="footer-top section">
			<div class="container">
				<div class="row">
					<div class="col-lg-5 col-md-6 col-12">
						<!-- Single Widget -->
						<div class="single-footer about">
							<div class="logo">
								<a href="index.html"><img src="images/brandlogo.png" alt="#"></a>
							</div>
							<p class="text">This page was created as a project by <br>Gautham<br>
							Sourav <br> Jayenth.</p>
							<p class="call">Got Question? Call us 24/7<span><a href="tel:123456789">123 456 789</a></span></p>
						</div>
						<!-- End Single Widget -->
					</div>
					<div class="col-lg-2 col-md-6 col-12">
						<!-- Single Widget -->
						<div class="single-footer links">
							<h4>Information</h4>
							<ul>
								<li><a href="#">About Us</a></li>
								<li><a href="#">Faq</a></li>
								<li><a href="#">Terms & Conditions</a></li>
								<li><a href="#">Contact Us</a></li>
								<li><a href="#">Help</a></li>
							</ul>
						</div>
						<!-- End Single Widget -->
					</div>
					<div class="col-lg-2 col-md-6 col-12">
						<!-- Single Widget -->
						<div class="single-footer links">
							<h4>Customer Service</h4>
							<ul>
								<li><a href="#">Payment Methods</a></li>
								<li><a href="#">Money-back</a></li>
								<li><a href="#">Returns</a></li>
								<li><a href="#">Shipping</a></li>
								<li><a href="#">Privacy Policy</a></li>
							</ul>
						</div>
						<!-- End Single Widget -->
					</div>
					<div class="col-lg-3 col-md-6 col-12">
						<!-- Single Widget -->
						<div class="single-footer social">
							<h4>Get In T0uch</h4>
							<!-- Single Widget -->
							<div class="contact">
								<ul>
									<li>M/1, pushkar apartments</li>
									<li>Chennai-80</li>
									<li>gauthammass2@gmail.com</li>
									<li>1234567891</li>
								</ul>
							</div>
							<!-- End Single Widget -->
							<ul>
								<li><a href="#"><i class="ti-facebook"></i></a></li>
								<li><a href="#"><i class="ti-twitter"></i></a></li>
								<li><a href="#"><i class="ti-flickr"></i></a></li>
								<li><a href="#"><i class="ti-instagram"></i></a></li>
							</ul>
						</div>
						<!-- End Single Widget -->
					</div>
				</div>
			</div>
		</div>
		<!-- End Footer Top -->
		<div class="copyright">
			<div class="container">
				<div class="inner">
					<div class="row">
						<div class="col-lg-6 col-12">
							<div class="left">
								<p>Copyright © 2022 <a href="http://www.wpthemesgrid.com" target="_blank">dbms project</a>  -  All Rights Reserved.</p>
							</div>
						</div>
						<div class="col-lg-6 col-12">
							<div class="right">
								<img src="images/payments.png" alt="#">
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
	</footer>
	<!-- /End Footer Area -->

	<!-- Jquery -->
    <script src="js/jquery.min.js"></script>
    <script src="js/jquery-migrate-3.0.0.js"></script>
	<script src="js/jquery-ui.min.js"></script>
	<!-- Popper JS -->
	<script src="js/popper.min.js"></script>
	<!-- Bootstrap JS -->
	<script src="js/bootstrap.min.js"></script>
	<!-- Color JS -->
	<script src="js/colors.js"></script>
	<!-- Slicknav JS -->
	<script src="js/slicknav.min.js"></script>
	<!-- Owl Carousel JS -->
	<script src="js/owl-carousel.js"></script>
	<!-- Magnific Popup JS -->
	<script src="js/magnific-popup.js"></script>
	<!-- Waypoints JS -->
	<script src="js/waypoints.min.js"></script>
	<!-- Countdown JS -->
	<script src="js/finalcountdown.min.js"></script>
	<!-- Nice Select JS -->
	<script src="js/nicesellect.js"></script>
	<!-- Flex Slider JS -->
	<script src="js/flex-slider.js"></script>
	<!-- ScrollUp JS -->
	<script src="js/scrollup.js"></script>
	<!-- Onepage Nav JS -->
	<script src="js/onepage-nav.min.js"></script>
	<!-- Easing JS -->
	<script src="js/easing.js"></script>
	<!-- Active JS -->
	<script src="js/active.js"></script>
	<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-ka7Sk0Gln4gmtz2MlQnikT1wXgYsOg+OMhuP+IlRH9sENBO0LRn5q+8nbTov4+1p" crossorigin="anonymous"></script>
</body>
</html>
