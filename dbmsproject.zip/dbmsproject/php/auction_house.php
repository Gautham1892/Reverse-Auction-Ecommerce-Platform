<!DOCTYPE html>
<html lang="zxx">
<head>
	<!-- Meta Tag -->
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name='copyright' content=''>
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
	<!-- Title Tag  -->
    <title>RevAuc</title>
	<!-- Favicon -->
	<link rel="icon" type="image/png" href="images/favicon.png">
	<!-- Web Font -->
	<link href="https://fonts.googleapis.com/css?family=Poppins:200i,300,300i,400,400i,500,500i,600,600i,700,700i,800,800i,900,900i&display=swap" rel="stylesheet">

	<!-- This meta tag will make the page refresh for every 60 seconds  -->
	<meta http-equiv = "refresh" content = "60" >
	<!-- StyleSheet -->

	<!-- Bootstrap -->
	<link rel="stylesheet" href="../css/bootstrap.css">
	<!-- Magnific Popup -->
    <link rel="stylesheet" href="../css/magnific-popup.min.css">
	<!-- Font Awesome -->
    <link rel="stylesheet" href="../css/font-awesome.css">
	<!-- Fancybox -->
	<link rel="stylesheet" href="../css/jquery.fancybox.min.css">
	<!-- Themify Icons -->
    <link rel="stylesheet" href="../css/themify-icons.css">
	<!-- Nice Select CSS -->
    <link rel="stylesheet" href="../css/niceselect.css">
	<!-- Animate CSS -->
    <link rel="stylesheet" href="../css/animate.css">
	<!-- Flex Slider CSS -->
    <link rel="stylesheet" href="../css/flex-slider.min.css">
	<!-- Owl Carousel -->
    <link rel="stylesheet" href="../css/owl-carousel.css">
	<!-- Slicknav -->
    <link rel="stylesheet" href="../css/slicknav.min.css">

	<!-- Eshop StyleSheet -->
	<link rel="stylesheet" href="../css/reset.css">
	<link rel="stylesheet" href="../style.css">
    <link rel="stylesheet" href="../css/responsive.css">

	<link href = "../css/main.css?v=<?php echo time(); ?>" rel = "stylesheet">


</head>
<body class="js">
	<?php
		$con = mysqli_connect("localhost" , "root" , "" , "revauc") ;
		if(mysqli_connect_error()){
			echo "Failed to connect to MySQL : ".mysqli_error() ;
			die() ;
		}
		session_start() ;
		if(!isset($_SESSION['id'])){
			//redirect to home page if no id is set
			echo '<script language="javascript">';
     						 echo 'window.location.replace("../index.php")';
      						echo '</script>';
		}

	?>
	<!-- Header -->
	<header class="header shop">


		<!-- Header Inner -->
		<div class="header-inner">
			<div class="container">
				<div class="cat-nav-head">
					<div class="row">
						<div class="col-lg-3">
							<div class="all-category">
							</div>
						</div>
						<div class="col-lg-9 col-12">
							<div class="menu-area">
								<!-- Main Menu -->
								<nav class="navbar navbar-expand-lg">
									<div class="navbar-collapse">
										<div class="nav-inner">
											<ul class="nav main-menu menu navbar-nav">
													<li class="active"><a href="#">Home</a></li>
													<li><a href="#">Product<i class="ti-angle-down"></i></a></li>
													<li><a href="#">Service</a></li>
													<li><a href="#">Category<i class="ti-angle-down"></i></a>
														<ul class="dropdown">
															<li><a href="shop-grid.html">Phones</a></li>
															<li><a href="cart.html">Laptops</a></li>
															<li><a href="checkout.html">Tvs</a></li>
														</ul>
													</li>

													<li><a href="#">Brands<i class="ti-angle-down"></i></a>
														<ul class="dropdown">
															<li><a href="blog-single-sidebar.html">Apple</a></li>
														</ul>
													</li>
													<li><a href="contact.html">Contact Us</a></li>
												</ul>
										</div>
									</div>
								</nav>
								<!--/ End Main Menu -->
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
		<!--/ End Header Inner -->
	</header>
	<!--/ End Header -->
        <!-- Code for the Auction house starts here  -->
		<div class="see-your-bids">

			<div class="auction-house-logout">
				<?php
									if(isset($_SESSION['id'])){
										?>
											<form action="../templates/logout.php" method = "POST">
												<button type = "submit"  value = "logout" name = "login" class = "navbar-btn">Logout</button>
											</form>

										<?php
									}
								?>
			</div>
			<h6><a href="vendor.php">See My Bids</a></h6>
		</div>
        <div class="filler"></div>
            <div class="container"  >
                    <div class="row a-header">
                    <h1 class = "auction-header" > ACTIVE BIDS </h1>
                    </div>
                    <!-- Auction Item With Timer Starts Here  -->

                    <?php
    //setting the timezone
    date_default_timezone_set('Asia/Kolkata') ;
    $i = 1 ;
    //$query = "SELECT * FROM demands , product WHERE demands.p_id = product.p_id " ;
	$query = "SELECT * FROM (SELECT * FROM demands LEFT JOIN vendor ON lowest_bidder = v_id) as t LEFT JOIN product ON t.p_id = product.p_id" ;
    $result = mysqli_query($con , $query) ;
    while($res = mysqli_fetch_array($result)){
        $date = $res['date'];
        $customer = $res['cust_id'] ;
		$demand_id = $res['d_id'] ;
        $h = $res['h'];
        $m = $res['m'];
        $s = $res['s'];
        $title = $res['title'] ;
		$link = $res['link']  ;
		$pro_title = $res['pro_title']  ;
        $thumbnail = $res['image1'] ;
        $bid_price = $res['bid_price'] ;
        $winning_vendor = $res['store_name'] ;
        $timestamp = strtotime("$date $h:$m:$s") ;

		//getting the details of the customer
		$q1 = "SELECT * FROM customer WHERE c_id = $customer" ;
		$tuple = mysqli_query($con , $q1) ;
		while($record = mysqli_fetch_array($tuple)){
			$customer_name = $record['name'] ;
		}
        ?>
        <div class="modal fade bd-example-modal-lg " id = "bidnowmodal<?php echo $i ; ?>" tabindex="-1" role="dialog" aria-labelledby="myLargeModalLabel" aria-hidden="true">
		<div class="modal-dialog modal-dialog-centered modal-lg" >
                <div class="modal-content">
                        <div class="bidnow-form">
                                <input type="hidden" id = "vendor<?php echo $i; ?>" value = "<?php echo $_SESSION['id'] ; ?>">
                                <input type = "hidden" id = "demand<?php echo $i ;?>" value = "<?php echo $demand_id;?>" >
                                <input type="number" id = "price<?php echo $i; ?>" placeholder = "Enter your Bid price"
                                max = <?php
								if(! $bid_price) echo 10000000 ;
								else echo $bid_price - 1 ; ?>
                                >  ;
                        </div>

                        <div class="modal-footer">
							<button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
							<button type="submit" data-bs-dismiss="modal" onclick = "bidder<?php echo $i ; ?>()" class = "btn btn-primary" >Bid Now</button>
						</div>
					</div>
		</div>
		</div>
    <script>
        //js function to update the db without refreshing
        function bidder<?php echo $i ; ?>(){
			var max_val<?php echo $i ;?>  = Number(document.getElementById('price<?php echo $i ;?>').max) ;
            var vendor = jQuery('#vendor<?php echo $i ; ?>').val() ;
            var demand = jQuery('#demand<?php echo $i ; ?>').val() ;
            var price<?php echo $i ; ?> = Number(jQuery('#price<?php echo $i ; ?>').val()) ;
			if(price<?php echo $i ; ?> > max_val<?php echo $i ;?>  ){
				alert('Your Bid price is higher than the current one , Bidding Failed!!') ;
				console.log(price<?php echo $i ; ?> > max_val<?php echo $i ;?> ) ;
			}
			else{
				document.getElementById("winner<?php echo $i ; ?>").innerHTML = '<?php echo $_SESSION['name'] ; ?>' ;
            document.getElementById("winprice<?php echo $i ; ?>").innerHTML = price<?php echo $i ; ?>  + ' INR';
			document.getElementById('price<?php echo $i ;?>').max = price<?php echo $i ; ?> ;
            jQuery.ajax({
                url : 'update.php' ,
                type : 'post' ,
                data :{
                    v_id : vendor ,
                    d_id : demand ,
                    bid_price : price<?php echo $i ; ?>
                } ,
                success : function(result){
                    console.log(result) ;
                }
            });
			alert('Bidding Success!!') ;
			}

        }
        var countDownDate<?php echo $i ; ?> = <?php
        echo strtotime("$date $h:$m:$s" ) ?> * 1000;
        var now = <?php echo time() ?> * 1000;
        //var now = <?php echo strtotime('now') ; ?> ;

        // Update the count down every 1 second
        var x<?php echo $i ; ?> = setInterval(function() {
        now = now + 1000;
        // Find the distance between now an the count down date
        var distance = countDownDate<?php echo $i ; ?>  - now;
        // Time calculations for days, hours, minutes and seconds
        var days = Math.floor(distance / (1000 * 60 * 60 * 24));
        var hours = Math.floor((distance % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60));
        var minutes = Math.floor((distance % (1000 * 60 * 60)) / (1000 * 60));
        var seconds = Math.floor((distance % (1000 * 60)) / 1000);
        // Output the result in an element with id="demo"
    document.getElementById('h<?php echo $i ; ?>').innerHTML = hours ;
    document.getElementById('m<?php echo $i ; ?>').innerHTML = minutes ;
            document.getElementById('s<?php echo $i ; ?>').innerHTML = seconds ;
        // If the count down is over, write some text
        if (distance < 0) {
        clearInterval(x<?php echo $i ; ?>);
        document.getElementById('h<?php echo $i ; ?>').style.display= 'none' ;
        document.getElementById('m<?php echo $i ; ?>').style.display= 'none' ;
        document.getElementById('s<?php echo $i ; ?>').style.display= 'none' ;
        document.getElementById('bidnow<?php echo $i; ?>').style.display = 'none' ;
        document.getElementById("demo<?php echo $i ; ?>").innerHTML = "EXPIRED";
        document.getElementById("demo<?php echo $i ; ?>").style.display = 'block' ;
        var disappear = document.getElementsByClassName('denotes<?php echo $i ;?>') ;
        for(var i = 0 ; i<disappear.length ;i++){
            disappear[i].style.display = 'none' ;
        }
        }

        }, 1000);
    </script>

                    <!-- Auction Item With Timer Ends Here  -->
                    <div class="row">
                        <div class="auction-item">
                            <div class="auction-image">
                                <img src = "<?php
								if(!$link) echo $thumbnail ;
								else echo 'default.png' ;
								?> " alt = "Image not found"/>
                            </div>
                            <div class="auction-details">
                                <div class="auction-details-title">
                                    <h5><?php
										if($link)echo $pro_title;
										else echo $title ;
										?>
								</h5>
                                </div>
								<?php
									if($link){
								?>
								<div class="bidder">
											<h6>
												<p>Product Link:</p>
												<a href = "<?php echo $link ; ?> "

												style ="margin :2px ; color :orange ;">
													See Product Details
											</a>
											</h6>
								</div>
								<?php } ?>
								<div class="bidder">
											<h6>
												<p>Customer:</p>
												<p><?php echo $customer_name ; ?> </p>
											</h6>
								</div>
                                <div class="auction-details-timebidder">
                                        <div class="bidder">

                                            <h6><p>Current-Bid-Winner : </p><p id = "winner<?php echo $i ; ?>">
                                        <?php
                                                if(!$winning_vendor) echo "N/A" ;
                                                else echo $winning_vendor ;
                                        ?>
                                        </p>
                                        </h6>
                                            <h6><p>Bid Price : </p><p id = "winprice<?php echo $i ; ?>">
                                        <?php
                                                if(!$bid_price) echo "N/A" ;
                                                else echo $bid_price.' INR' ;
                                        ?>
                                        </p>
                                        </h6>
                                        </div>
                                        <div class="auction-timer">
                                        <div class="expired" id = 'demo<?php echo $i ; ?>'></div>
                                            <div class="auction-hours time-boxes" id = 'h<?php echo $i ; ?>' >
                                                00
                                            </div>
                                            <div class="time-denote denotes<?php echo $i; ?>">
                                                h
                                            </div>
                                            <div class="auction-minutes time-boxes" id = 'm<?php echo $i ; ?>' >
                                                00
                                            </div>
                                            <div class="time-denote denotes<?php echo $i; ?>">
                                                m
                                            </div>
                                            <div class="auction-seconds time-boxes" id = 's<?php echo $i ; ?>' >
                                                00
                                            </div>
                                            <div class="time-denote denotes<?php echo $i; ?>">
                                                sec
                                            </div>
                                        </div>
                                </div>
                                <div class="auction-details-bidnow">
                                    <button type = "button" class = "btn btn-primary" data-bs-toggle = "modal" data-bs-target = "#bidnowmodal<?php echo $i ; ?>" id = 'bidnow<?php echo $i; ?>'>Bid Now</button>
                                </div>
                            </div>
                        </div>
                    </div>

            <?php
    $i++ ;
} ?>
</div>
            <div class="filler"></div>
        <!-- Code for the Auction house ends here  -->

<!-- Start Footer Area -->
	<footer class="footer">
		<!-- Footer Top -->
		<div class="footer-top section">
			<div class="container">
				<div class="row">
					<div class="col-lg-5 col-md-6 col-12">
						<!-- Single Widget -->
						<div class="single-footer about">
							<div class="logo">
								<a href="index.html"><img src="images/brandlogo.png" alt="#"></a>
							</div>
							<p class="text">This page was created as a project by <br>Gautham<br>
							Sourav <br> Jayenth.</p>
							<p class="call">Got Question? Call us 24/7<span><a href="tel:123456789">123 456 789</a></span></p>
						</div>
						<!-- End Single Widget -->
					</div>
					<div class="col-lg-2 col-md-6 col-12">
						<!-- Single Widget -->
						<div class="single-footer links">
							<h4>Information</h4>
							<ul>
								<li><a href="#">About Us</a></li>
								<li><a href="#">Faq</a></li>
								<li><a href="#">Terms & Conditions</a></li>
								<li><a href="#">Contact Us</a></li>
								<li><a href="#">Help</a></li>
							</ul>
						</div>
						<!-- End Single Widget -->
					</div>
					<div class="col-lg-2 col-md-6 col-12">
						<!-- Single Widget -->
						<div class="single-footer links">
							<h4>Customer Service</h4>
							<ul>
								<li><a href="#">Payment Methods</a></li>
								<li><a href="#">Money-back</a></li>
								<li><a href="#">Returns</a></li>
								<li><a href="#">Shipping</a></li>
								<li><a href="#">Privacy Policy</a></li>
							</ul>
						</div>
						<!-- End Single Widget -->
					</div>
					<div class="col-lg-3 col-md-6 col-12">
						<!-- Single Widget -->
						<div class="single-footer social">
							<h4>Get In T0uch</h4>
							<!-- Single Widget -->
							<div class="contact">
								<ul>
									<li>M/1, pushkar apartments</li>
									<li>Chennai-80</li>
									<li>gauthammass2@gmail.com</li>
									<li>1234567891</li>
								</ul>
							</div>
							<!-- End Single Widget -->
							<ul>
								<li><a href="#"><i class="ti-facebook"></i></a></li>
								<li><a href="#"><i class="ti-twitter"></i></a></li>
								<li><a href="#"><i class="ti-flickr"></i></a></li>
								<li><a href="#"><i class="ti-instagram"></i></a></li>
							</ul>
						</div>
						<!-- End Single Widget -->
					</div>
				</div>
			</div>
		</div>
		<!-- End Footer Top -->
		<div class="copyright">
			<div class="container">
				<div class="inner">
					<div class="row">
						<div class="col-lg-6 col-12">
							<div class="left">
								<p>Copyright © 2022 <a href="http://www.wpthemesgrid.com" target="_blank">dbms project</a>  -  All Rights Reserved.</p>
							</div>
						</div>
						<div class="col-lg-6 col-12">
							<div class="right">
								<img src="images/payments.png" alt="#">
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
	</footer>
	<!-- /End Footer Area -->

	<!-- Jquery -->
    <script src="../js/jquery.min.js"></script>
    <script src="../js/jquery-migrate-3.0.0.js"></script>
	<script src="../js/jquery-ui.min.js"></script>
	<!-- Popper JS -->
	<script src="../js/popper.min.js"></script>
	<!-- Bootstrap JS -->
	<script src="../js/bootstrap.min.js"></script>
	<!-- Color JS -->
	<script src="../js/colors.js"></script>
	<!-- Slicknav JS -->
	<script src="../js/slicknav.min.js"></script>
	<!-- Owl Carousel JS -->
	<script src="../js/owl-carousel.js"></script>
	<!-- Magnific Popup JS -->
	<script src="../js/magnific-popup.js"></script>
	<!-- Waypoints JS -->
	<script src="../js/waypoints.min.js"></script>
	<!-- Countdown JS -->
	<script src="../js/finalcountdown.min.js"></script>
	<!-- Nice Select JS -->
	<script src="../js/nicesellect.js"></script>
	<!-- Flex Slider JS -->
	<script src="../js/flex-slider.js"></script>
	<!-- ScrollUp JS -->
	<script src="../js/scrollup.js"></script>
	<!-- Onepage Nav JS -->
	<script src="../js/onepage-nav.min.js"></script>
	<!-- Easing JS -->
	<script src="../js/easing.js"></script>
	<!-- Active JS -->
	<script src="../js/active.js"></script>
	<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-ka7Sk0Gln4gmtz2MlQnikT1wXgYsOg+OMhuP+IlRH9sENBO0LRn5q+8nbTov4+1p" crossorigin="anonymous"></script>
</body>
</html>
