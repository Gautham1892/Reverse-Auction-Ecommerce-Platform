<!DOCTYPE HTML>
<html>
	<head>
		<title>RevAuc-Products</title>
		<link href="../css/bootstrap.min.css" rel='stylesheet' type='text/css' />
		<link href="../css/bootstrap.css" rel='stylesheet' type='text/css' />
		<link href="../css/theme.css" rel='stylesheet' type='text/css' />

		<link rel="icon" type="image/png" href="../images/favicon.png">

	<!-- Bootstrap -->
	<link rel="stylesheet" href="../css/bootstrap.css">
	<!-- Magnific Popup -->
    <link rel="stylesheet" href="../css/magnific-popup.min.css">
	<!-- Font Awesome -->
    <link rel="stylesheet" href="../css/font-awesome.css">
	<!-- Fancybox -->
	<link rel="stylesheet" href="../css/jquery.fancybox.min.css">
	<!-- Themify Icons -->
    <link rel="stylesheet" href="../css/themify-icons.css">
	<!-- Nice Select CSS -->
    <link rel="stylesheet" href="../css/niceselect.css">
	<!-- Animate CSS -->
    <link rel="stylesheet" href="../css/animate.css">
	<!-- Flex Slider CSS -->
    <link rel="stylesheet" href="../css/flex-slider.min.css">
	<!-- Owl Carousel -->
    <link rel="stylesheet" href="../css/owl-carousel.css">
	<!-- Slicknav -->
    <link rel="stylesheet" href="../css/slicknav.min.css">
	<link rel = "stylesheet" href = "../css/main.css?v=<?php echo time() ; ?>">
	<!-- Eshop StyleSheet -->
	<link rel="stylesheet" href="../css/reset.css">
	<link rel="stylesheet" href="../style.css">
    <link rel="stylesheet" href="../css/responsive.css">

		<meta name="viewport" content="width=device-width, initial-scale=1">
		<script type="application/x-javascript"> addEventListener("load", function() { setTimeout(hideURLbar, 0); }, false); function hideURLbar(){ window.scrollTo(0,1); } </script>
		</script>
		<!----webfonts---->
		<link href='http://fonts.googleapis.com/css?family=Open+Sans:400,600,700,800,300' rel='stylesheet' type='text/css'>
		<!----//webfonts---->
		<script type="text/javascript" src="../js/jquery.min.js"></script>
		<script type="text/javascript" src="../js/bootstrap.js"></script>
		<script type="text/javascript" src="../js/bootstrap.min.js"></script>
		<!--  jquery plguin -->
	    <script type="text/javascript" src="../js/jquery.min.js"></script>
	    <!-- start details -->
<!----details-product-slider--->
				<!-- Include the Etalage files -->
					<link rel="stylesheet" href="../css/etalage.css">
					<script src="../js/jquery.etalage.min.js"></script>
				<!-- Include the Etalage files -->
				<script>
						jQuery(document).ready(function($){

							$('#etalage').etalage({
								thumb_image_width: 300,
								thumb_image_height: 400,

								show_hint: true,
								click_callback: function(image_anchor, instance_id){
									alert('Callback example:\nYou clicked on an image with the anchor: "'+image_anchor+'"\n(in Etalage instance: "'+instance_id+'")');
								}
							});
							// This is for the dropdown list example:
							$('.dropdownlist').change(function(){
								etalage_show( $(this).find('option:selected').attr('class') );
							});

					});
				</script>
				<!---//details-product-slider--->



	</head>
	<body>
	<?php
		$con = mysqli_connect("localhost" , "root" , "" , "revauc") ;
		if(mysqli_connect_errno()){
			echo "Failed to connect to MySQL : ".mysqli_error() ;
			die() ;
		}
		session_start() ;
		if($_SERVER['REQUEST_METHOD'] == 'POST'){
			if(isset($_POST['login']) && $_POST['login'] == 'customerLogin'){
				//here complete validation for the customer login is done
				//if the details are okay then some session variables are created
				$mail = $_POST['mail'] ;
				$password = $_POST['pass'] ;
				$query = "SELECT * FROM customer WHERE email = '$mail'" ; //fetching the details of the customer who has the entered email
				$res = mysqli_query($con , $query) ;
				$error_flag = 1 ;
				if(mysqli_num_rows($res) == 0){
					//the entered email ID doesn't exist in the Database
					echo "<script> alert('Entered email does not exist');</script>" ;
					$error_flag = 0 ;
				}
				if($error_flag){
					//this will execute when the entered email is in the database
					while($row = mysqli_fetch_array($res)){
						if($row['password'] == $password){
							// control will come into this block only if the password match
							$_SESSION['name'] = $row['name'] ;
							$_SESSION['id'] = $row['c_id'] ;
							$_SESSION['login_type'] = 'C' ;
						}
						else{
							//when wrong password has been entered
							echo "<script> alert('You have entered wrong password');</script>" ;
						}
					}
				}
			}
			else if(isset($_POST['login']) && $_POST['login'] == 'vendorLogin'){
				//echo "hello , I am in ! <br>" ;
				$mail = $_POST['mail'] ;
				$password = $_POST['pass'] ;
				$query = "SELECT * FROM vendor WHERE email = '$mail'" ;
				$res = mysqli_query($con , $query) ;
				$error_flag = 1 ;
				if(mysqli_num_rows($res) == 0){
					//email doesn't exist in the database
					$error_flag = 0 ;
					echo "<script> alert('Entered email does not exist');</script>" ;
				}
				if($error_flag){
					while($row = mysqli_fetch_array($res)){
						if($password == $row['password']){
							//entered password matches
							$_SESSION['name'] = $row['store_name'] ;
							$_SESSION['id'] = $row['v_id'] ;
							$_SESSION['login_type'] = 'V' ;
							echo '<script language="javascript">';
     						 echo 'window.location.replace("php/market.php")';
      						echo '</script>';
						}
						else{
							echo "<script> alert('You have entered the wrong password');</script>" ;
						}
					}
				}
			}
		}
	?>

<?php
		if(isset($_SESSION['login_type']) && $_SESSION['login_type'] == 'V'){
			echo '<script language="javascript">';
     						 echo 'window.location.replace("php/auction_house.php")';
      						echo '</script>';
		}
	?>
		<?php

			if(isset ($_GET['pro'])) $pro_id = $_GET['pro'] ;
			else $pro_id = $pro_copy ;
			$pro_copy = $pro_id ;

			//here the code for raising demand will be written
			if(isset($_POST['raise'])){
				$customer = $_SESSION['id'] ;
				$pro = $pro_id ;
				$date = $_POST['demand_date'] ;
				$hours = $_POST['hours'] ;
				$minutes = $_POST['minutes'] ;
				$seconds = $_POST['seconds'] ;
				$query = "INSERT INTO demands(cust_id , date , h , m ,s , p_id) VALUES ($customer , '$date' , $hours , $minutes , $seconds , '$pro')" ;
				$res  = mysqli_query($con , $query) ;
			}

			$query = "SELECT * FROM product WHERE p_id = '$pro_id'";
			$res = mysqli_query($con , $query) ;
		?>

		<!----start-container---->
			<header class="header shop">
		<!-- Topbar -->
		<div class="topbar">
			<div class="container">
				<div class="row">
					<div class="col-lg-4 col-md-12 col-12">
						<!-- Top Left -->
						<div class="top-left">
							<ul class="list-main">
								<li><i class="ti-headphone-alt"></i> 9003666098</li>
								<li><i class="ti-email"></i> gauthammass2@gmail.com</li>
							</ul>
						</div>
						<!--/ End Top Left -->
					</div>
					<div class="col-lg-8 col-md-12 col-12">
						<!-- Top Right -->
						<div class="right-content">
							<ul class="list-main">
								<li><i class="ti-location-pin"></i> Store location</li>
								<li><i class="ti-alarm-clock"></i> <a href="#">Daily deal</a></li>
								<?php
								if(isset($_SESSION['id'])){
								?>
								<li><i class="ti-user"></i> <a href="customer.php">Hello <?php echo $_SESSION['name'];?> !</a></li>
								<?php } ?>
								<?php
									if(isset($_SESSION['id'])){
										?>
										<li>
											<form action="../templates/logout.php" method = "POST">
												<button type = "submit"  value = "logout" name = "login" class = "navbar-btn">Logout</button>
											</form>
										</li>
										<?php
									}
									else{
								?>
								<li><button type="button" class="navbar-btn" data-bs-toggle="modal" data-bs-target="#vendor-login">Vendor Login</button></li>
								<li><button type="button" class="navbar-btn" data-bs-toggle="modal" data-bs-target="#customer-login">Customer Login</button></li>
								<?php } ?>
							</ul>
						</div>
						<!-- End Top Right -->
					</div>
				</div>
			</div>
		</div>

		<!-- Customer Login modal -->
		<div class="modal fade bd-example-modal-lg " id = "customer-login" tabindex="-1" role="dialog" aria-labelledby="myLargeModalLabel" aria-hidden="true">
		<div class="modal-dialog modal-dialog-centered modal-lg" >
			<div class="modal-content login-modal" >
				<section class = "Form">
					<div class="container">
						<div class="row ">
							<div class="col-lg-5">
								<img src="../images/customer.jpeg" class = "img-fluid" style = "height: 100% ; width : 100%" alt="Responsive Image">
							</div>
							<div class="col-lg-7 ml-auto d-flex flex-column  align-items-center">
								<h1 class = "font-weight-bold py-3 login-header" style = "font-size: 40px ;">
									RevAuc
								</h1>
								<h3 style = "font-size: 35px ;" >Customer-Login</h3>
								<form action = "" method = "POST">
									<div class="form-row">
										<div class="col-lg-12">
											<input type  = "email" placeholder="Enter Email Address" name = "mail" class = "form-control my-3 p-2 login-form" required style = "font-size: 15px ;">
										</div>
									</div>
									<div class="form-row">
										<div class="col-lg-12">
											<input type  = "password" placeholder="Enter Password" name = "pass" class = "form-control my-3 p-2 login-form" required style = "font-size: 15px ;">
										</div>
									</div>
									<div class="form-row">
										<div class="col-lg-12 ">
											<button type = "submit" name = "login" value = "customerLogin" class = "login-btn my-3 p-2" style = "font-size : 20px ;">Login</button>
										</div>
									</div>
									<a href = "#" class = "link-secondary login-link">Forgot Password</a>
									<p>Don't have an account ? <a href="registration_customer.php" class = "link-secondary login-link">Register Here</a></p>
								</form>
							</div>
						</div>
					</div>
				</section>

			</div>
		</div>
		</div>

    <!-- Vendor Login modal -->
	<div class="modal fade bd-example-modal-lg " id = "vendor-login" tabindex="-1" role="dialog" aria-labelledby="myLargeModalLabel" aria-hidden="true">
		<div class="modal-dialog modal-dialog-centered modal-lg" >
			<div class="modal-content login-modal" >
				<section class = "Form">
					<div class="container">
						<div class="row ">
							<div class="col-lg-5">
								<img src="../images/vendor.jpeg" class = "img-fluid" style = "height: 100% ; width : 100%" alt="Responsive Image">
							</div>
							<div class="col-lg-7 ml-auto d-flex flex-column  align-items-center">
								<h1 class = "font-weight-bold py-3 login-header" style = "font-size:40px ;">
									RevAuc
								</h1>
								<h3 style = "font-size: 35px ;">Vendor-Login</h3>
								<form action = "" method = "POST">
									<div class="form-row">
										<div class="col-lg-12">
											<input type  = "email" placeholder="Enter Email Address" name = "mail" class = "form-control my-3 p-2 login-form" style = "font-size: 15px ;" required>
										</div>
									</div>
									<div class="form-row">
										<div class="col-lg-12">
											<input type  = "password" placeholder="Enter Password" name = "pass" class = "form-control my-3 p-2 login-form" style = "font-size: 15px ;" required>
										</div>
									</div>
									<div class="form-row">
										<div class="col-lg-12 ">
											<button type = "submit" value = "vendorLogin" name = "login" class = "login-btn my-3 p-2" style = "font-size: 20px ;">Login</button>
										</div>
									</div>
									<a href = "#" class = "link-secondary login-link">Forgot Password</a>
									<p>Don't have an account ? <a href="registration_vendor.php" class = "link-secondary login-link">Register Here</a></p>
								</form>
							</div>
						</div>
					</div>
				</section>

			</div>
		</div>
		</div>
		<!-- set timer modal starts here  -->
		<div class="modal fade bd-example-modal-lg " id = "set-timer" tabindex="-1" role="dialog" aria-labelledby="myLargeModalLabel" aria-hidden="true">
		<div class="modal-dialog modal-dialog-centered modal-lg" >
					<div class="modal-content set-timer">
							<h1 class = "setTimerHeader">Set the Bid Timer</h1>
						<div class="setTimer-body">
							<form action = "" method = "POST">
							<table class="table-striped">
								<tbody>
									<tr>
										<td><input type="date" name = 'demand_date'></td>
										<td><input type = "number" value = 0 name = "hours"  max = 23 min = 0 /></td>
										<td><input type = "number" value = 0 name = "minutes"  max = 59 min = 0  /></td>
										<td><input type = "number" value = 0 name = "seconds" max = 59 min = 0 /></td>
									</tr>
									<tr>
										<td>Date</td>
										<td>Hours</td>
										<td>Minutes</td>
										<td>Seconds</td>
									</tr>
								</tbody>
								</table>

						</div>
						<div class="modal-footer">
							<button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
							<button type="submit" name = "raise" value = "Raise Demand" class = "btn btn-primary" >Raise Demand</button>
						</div>
						</form>
					</div>
		</div>
		</div>
		<!-- set timer modal ends here  -->
	</header>
			<?php
			if($res == false) echo $con ->error ;
			while(mysqli_num_rows($res) > 0 && $row = mysqli_fetch_array($res)){ ?>
    <div class="single">
         <div class="container">

		<div class="cont span_2_of_3">
			 <div class="labout span_1_of_a1">
				<!-- start product_slider -->
				     <ul id="etalage">
							<li>
								<a href="optionallink.html">
									<img class="etalage_thumb_image" src = <?php echo $row['image1'] ;  ?> />
									<img class="etalage_source_image" src = <?php echo $row['image1'] ;  ?> />
								</a>
							</li>
							<li>
								<img class="etalage_thumb_image" src =  <?php echo $row['image2'] ; ?> />
								<img class="etalage_source_image" src =  <?php echo $row['image2'] ; ?> />
							</li>
							<li>
								<img class="etalage_thumb_image" src =  <?php echo $row['image3'] ; ?> />
								<img class="etalage_source_image" src =  <?php echo $row['image3'] ; ?> />
							</li>
							<li>
								<img class="etalage_thumb_image" src =  <?php echo $row['image4'] ; ?> />
								<img class="etalage_source_image" src =  <?php echo $row['image4'] ; ?> />
							</li>
							<li>
								<img class="etalage_thumb_image" src =  <?php echo $row['image4'] ; ?> />
								<img class="etalage_source_image" src =  <?php echo $row['image4'] ; ?> />
							</li>
							<li>
								<img class="etalage_thumb_image" src =  <?php echo $row['image2'] ; ?> />
								<img class="etalage_source_image" src =  <?php echo $row['image2'] ; ?> />
							</li>
							<li>
								<img class="etalage_thumb_image" src =  <?php echo $row['image3'] ; ?> />
								<img class="etalage_source_image" src =  <?php echo $row['image3'] ; ?> />
							</li>
						</ul>


			<!-- end product_slider -->
			</div>
			<div class="cont1 span_2_of_a1 pull-right">
				<h3 class="m_3"><?php echo $row['title'] ;?> </h3>

				<!--<div class="price_single">
							  <span class="reducedfrom">Rs.91000.00</span>
							  <span class="actual">Rs.68000.00</span><a href="#">click for offer</a>
							</div>-->
				<!-- <ul class="options list-unstyled">
					<h4 class="m_9">Select a Size</h4>
					<li><a href="#">6</a></li>
					<li><a href="#">7</a></li>
					<li><a href="#">8</a></li>
					<li><a href="#">9</a></li>
					<div class="clearfix"></div>
				</ul> -->

				<div class="btn_form">
					<?php
						if(isset($_SESSION['name'])){
					?>
				   <button type="button" class="shop-login-btn" data-bs-toggle="modal" data-bs-target="#set-timer">Raise Demand</button>

				  <?php }
				 else{
				?>
					<button type="button" class="shop-login-btn" data-bs-toggle="modal" data-bs-target="#customer-login">Login</button>
				<?php
				 }
				 ?>
				</div>
				<ul class="add-to-links list-unstyled">
    			   <li><img src="images/wish.png" alt=""><a href="#">Add to wishlist</a></li>
    			</ul>
    			<p class="m_3"> <?php echo $row['detail'] ;?></p>
				 <br><br>
				 <h3 class="m_3">About this item</h3>
				 <p class="m_3"><?php echo $row['description'] ; ?>
			</p><br>

                <div class="social_single">
				   <ul list-unstyled>
					  <li class="fb"><a href="#"><span> </span></a></li>
					  <li class="tw"><a href="#"><span> </span></a></li>
					  <li class="g_plus"><a href="#"><span> </span></a></li>
					  <li class="rss"><a href="#"><span> </span></a></li>
				   </ul>
			    </div>
			</div>
			<div class="clearfix"></div>
         </div>


	<script type="text/javascript" src="../js/jquery.flexisel.js"></script>
	 <div class="toogle">
     	<h3 class="m_3">Product Details</h3>
     	<!-- Entering the product details here using the tables from bootstrap to display
		 the details  -->
		 <table class="table table-striped">
		<tbody>
				<tr>
					<th scope = "row">Category</th>
					<td><?php echo $row['category'] ; ?></td>
				</tr>
				<tr>
					<th scope = "row">Brand</th>
					<td> <?php echo $row['brand'] ; ?> </td>
				</tr>
				<tr>
					<th scope = "row">Model</th>
					<td> <?php echo $row['model'] ; ?></td>
				</tr>
				<tr>
					<th scope = "row">RAM</th>
					<td><?php echo $row['ram'] ;?></td>
				</tr>
				<tr>
					<th scope = "row"> Storage </th>
					<td><?php echo $row['storage'] ;  ?></td>
				</tr>
				<tr>
					<th scope = "row">Processor</th>
					<td><?php echo $row['processor'] ; ?></td>
				</tr>
				<tr>
					<th scope = "row">OS</th>
					<td> <?php echo $row['os'] ; ?> </td>
				</tr>
				<tr>
					<th scope = "row">Colour</th>
					<td><?php echo $row['colour'] ; ?></td>
				</tr>
				<tr>
					<th scope = "row">Dimensions</th>
					<td> <?php echo $row['dimension'] ; ?> </td>
				</tr>

  			</tbody>
		</table>


     </div>
     </div>
     <div class="clearfix"></div>
	 </div>

	 <?php } ?>
	<footer class="footer">
		<!-- Footer Top -->
		<div class="footer-top section">
			<div class="container">
				<div class="row">
					<div class="col-lg-5 col-md-6 col-12">
						<!-- Single Widget -->
						<div class="single-footer about">
							<div class="logo">
								<a href="index.html"><img src="images/lo0go2.png" alt="#"></a>
							</div>
							<p class="text"></p>
							<p class="call">Got Question? Call us 24/7<span><a href="tel:123456789">123 456 789</a></span></p>
						</div>
						<!-- End Single Widget -->
					</div>
					<div class="col-lg-2 col-md-6 col-12">
						<!-- Single Widget -->
						<div class="single-footer links">
							<h4>Information</h4>
							<ul>
								<li><a href="#">About Us</a></li>
								<li><a href="#">Faq</a></li>
								<li><a href="#">Terms & Conditions</a></li>
								<li><a href="#">Contact Us</a></li>
								<li><a href="#">Help</a></li>
							</ul>
						</div>
						<!-- End Single Widget -->
					</div>
					<div class="col-lg-2 col-md-6 col-12">
						<!-- Single Widget -->
						<div class="single-footer links">
							<h4>Customer Service</h4>
							<ul>
								<li><a href="#">Payment Methods</a></li>
								<li><a href="#">Money-back</a></li>
								<li><a href="#">Returns</a></li>
								<li><a href="#">Shipping</a></li>
								<li><a href="#">Privacy Policy</a></li>
							</ul>
						</div>
						<!-- End Single Widget -->
					</div>
					<div class="col-lg-3 col-md-6 col-12">
						<!-- Single Widget -->
						<div class="single-footer social">
							<h4>Get In Touch</h4>
							<!-- Single Widget -->
							<div class="contact">
								<ul>
									<li>M/1, Pushkar Apartments</li>
									<li>Chennai-80</li>
									<li>gauthammass2@gmail.com</li>
									<li>9003666098</li>
								</ul>
							</div>
							<!-- End Single Widget -->
							<ul>
								<li><a href="#"><i class="ti-facebook"></i></a></li>
								<li><a href="#"><i class="ti-twitter"></i></a></li>
								<li><a href="#"><i class="ti-flickr"></i></a></li>
								<li><a href="#"><i class="ti-instagram"></i></a></li>
							</ul>
						</div>
						<!-- End Single Widget -->
					</div>
				</div>
			</div>
		</div>
		<!-- End Footer Top -->
		<div class="copyright">
			<div class="container">
				<div class="inner">
					<div class="row">
						<div class="col-lg-6 col-12">
							<div class="left">
								<p>Copyright © 2022 <a href="http://www.wpthemesgrid.com" target="_blank">Telpathri singh</a>  -  All Rights Reserved.</p>
							</div>
						</div>
						<div class="col-lg-6 col-12">
							<div class="right">
								<img src="images/payments.png" alt="#">
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
	</footer>
	<!-- /End Footer Area -->

	<!-- Jquery -->
    <script src="../js/jquery.min.js"></script>
    <script src="../js/jquery-migrate-3.0.0.js"></script>
	<script src="../js/jquery-ui.min.js"></script>
	<!-- Popper JS -->
	<script src="../js/popper.min.js"></script>
	<!-- Bootstrap JS -->
	<script src="../js/bootstrap.min.js"></script>
	<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-ka7Sk0Gln4gmtz2MlQnikT1wXgYsOg+OMhuP+IlRH9sENBO0LRn5q+8nbTov4+1p" crossorigin="anonymous"></script>
	<!-- Color JS -->
	<script src="../js/colors.js"></script>
	<!-- Slicknav JS -->
	<script src="../js/slicknav.min.js"></script>
	<!-- Owl Carousel JS -->
	<script src="../js/owl-carousel.js"></script>
	<!-- Magnific Popup JS -->
	<script src="../js/magnific-popup.js"></script>
	<!-- Waypoints JS -->
	<script src="../js/waypoints.min.js"></script>
	<!-- Countdown JS -->
	<script src="../js/finalcountdown.min.js"></script>
	<!-- Nice Select JS -->
	<script src="../js/nicesellect.js"></script>
	<!-- Flex Slider JS -->
	<script src="../js/flex-slider.js"></script>
	<!-- ScrollUp JS -->
	<script src="../js/scrollup.js"></script>
	<!-- Onepage Nav JS -->
	<script src="../js/onepage-nav.min.js"></script>
	<!-- Easing JS -->
	<script src="../js/easing.js"></script>
	<!-- Active JS -->
	<script src="../js/active.js"></script>
</body>
</html>
