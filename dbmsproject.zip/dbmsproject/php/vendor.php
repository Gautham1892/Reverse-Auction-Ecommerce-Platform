<!DOCTYPE html>
<html lang="zxx">
<head>
	<!-- Meta Tag -->
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name='copyright' content=''>
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
	<!-- Title Tag  -->
    <title>RevAuc</title>
	<!-- Favicon -->
	<link rel="icon" type="image/png" href="images/favicon.png">
	<!-- Web Font -->
	<link href="https://fonts.googleapis.com/css?family=Poppins:200i,300,300i,400,400i,500,500i,600,600i,700,700i,800,800i,900,900i&display=swap" rel="stylesheet">

	<!-- StyleSheet -->
    <!-- This meta tag will make the page refresh for every 60 seconds  -->
	<meta http-equiv = "refresh" content = "60" >
	<!-- Bootstrap -->
	<link rel="stylesheet" href="../css/bootstrap.css">
	<!-- Magnific Popup -->
    <link rel="stylesheet" href="../css/magnific-popup.min.css">
	<!-- Font Awesome -->
    <link rel="stylesheet" href="../css/font-awesome.css">
	<!-- Fancybox -->
	<link rel="stylesheet" href="../css/jquery.fancybox.min.css">
	<!-- Themify Icons -->
    <link rel="stylesheet" href="../css/themify-icons.css">
	<!-- Nice Select CSS -->
    <link rel="stylesheet" href="../css/niceselect.css">
	<!-- Animate CSS -->
    <link rel="stylesheet" href="../css/animate.css">
	<!-- Flex Slider CSS -->
    <link rel="stylesheet" href="../css/flex-slider.min.css">
	<!-- Owl Carousel -->
    <link rel="stylesheet" href="../css/owl-carousel.css">
	<!-- Slicknav -->
    <link rel="stylesheet" href="../css/slicknav.min.css">

	<!-- Eshop StyleSheet -->
	<link rel="stylesheet" href="../css/reset.css">
	<link rel="stylesheet" href="../style.css">
    <link rel="stylesheet" href="../css/responsive.css">

	<link href = "../css/main.css?v=<?php echo time(); ?>" rel = "stylesheet">


</head>
<body class="js">
	<?php
		$con = mysqli_connect("localhost" , "root" , "" , "revauc") ;
		if(mysqli_connect_error()){
			echo "Failed to connect to MySQL : ".mysqli_error() ;
			die() ;
		}
		session_start() ;


	?>


	<!-- Header -->
	<header class="header shop">


		<!-- Header Inner -->
		<div class="header-inner">
			<div class="container">
				<div class="cat-nav-head">
					<div class="row">
						<div class="col-lg-3">
							<div class="all-category">
							</div>
						</div>
						<div class="col-lg-9 col-12">
							<div class="menu-area">
								<!-- Main Menu -->
								<nav class="navbar navbar-expand-lg">
									<div class="navbar-collapse">
										<div class="nav-inner">
											<ul class="nav main-menu menu navbar-nav">
													<li class="active"><a href="../index.php">Home</a></li>
													<li><a href="#">Product<i class="ti-angle-down"></i></a></li>
													<li><a href="#">Service</a></li>
													<li><a href="#">Category<i class="ti-angle-down"></i></a>
														<ul class="dropdown">
															<li><a href="shop-grid.html">Phones</a></li>
															<li><a href="cart.html">Laptops</a></li>
															<li><a href="checkout.html">Tvs</a></li>
														</ul>
													</li>

													<li><a href="#">Brands<i class="ti-angle-down"></i></a>
														<ul class="dropdown">
															<li><a href="blog-single-sidebar.html">Apple</a></li>
														</ul>
													</li>
													<li><a href="contact.html">Contact Us</a></li>
												</ul>
										</div>
									</div>
								</nav>
								<!--/ End Main Menu -->
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
		<!--/ End Header Inner -->
	</header>
	<!--/ End Header -->
        <!-- code for the vendor's current bids is seen here  -->
        <?php
        //querying the vendor details
        $v = $_SESSION['id'] ;
        $query = "SELECT * FROM vendor WHERE v_id = $v" ;
        $res = mysqli_query($con , $query) ;
        while($row = mysqli_fetch_array($res)){
            $store_name = $row['store_name'] ;
            $owner_name = $row['owner_name'] ;
            $vendor_phone_number = $row['phone'] ;
        }

        ?>
		<div class="vendor-details">

            <div class="vendor-name">
                    <div class="vendor-store-name">
                        <h6>Store Name : </h6>
                        <p><?php echo $store_name ?></p>
                    </div>
                    <div class="vendor-owner-name">
                        <h6>Owner Name : </h6>
                        <p><?php echo $owner_name ?></p>
                    </div>
            </div>
            <div class="vendor-phone-number">
            <h6>Phone Number  : </h6>
                        <p><?php echo $vendor_phone_number ?></p>
            </div>
        </div>
        <div class="filler"></div>

        <div class="container"  >
                    <div class="row a-header">
                    <h1 class = "auction-header" > YOUR CURRENT BIDS </h1>
                    </div>
                    <div class="bid-more-buddy">
                        <h5><a href="auction_house.php">Bid more >> </a></h5>

                    </div>
                    <!-- Auction Item With Timer Starts Here  -->

                    <?php
    //setting the timezone
    date_default_timezone_set('Asia/Kolkata') ;
    $i = 1 ;
    //$query = "SELECT * FROM demands , product WHERE demands.p_id = product.p_id " ;
	$query = "SELECT * FROM (SELECT * FROM demands LEFT JOIN vendor ON lowest_bidder = v_id) as t LEFT JOIN product ON t.p_id = product.p_id WHERE v_id = $v" ;
    $result = mysqli_query($con , $query) ;
    while($res = mysqli_fetch_array($result)){
        $date = $res['date'];
        $customer = $res['cust_id'] ;
		$demand_id = $res['d_id'] ;
        $h = $res['h'];
        $m = $res['m'];
        $s = $res['s'];
        $link = $res['link'] ;
        $pro_title = $res['pro_title'] ;
        $title = $res['title'] ;
        $thumbnail = $res['image1'] ;
        $bid_price = $res['bid_price'] ;
        $winning_vendor = $res['store_name'] ;
        $timestamp = strtotime("$date $h:$m:$s") ;

		//getting the details of the customer
		$q1 = "SELECT * FROM customer WHERE c_id = $customer" ;
		$tuple = mysqli_query($con , $q1) ;
		while($record = mysqli_fetch_array($tuple)){
			$customer_name = $record['name'] ;
		}
        ?>
    <script>
        //js function to update the db without refreshing
        function bidder<?php echo $i ; ?>(){
			var max_val  = document.getElementById('price<?php echo $i ;?>').max ;
            var vendor = jQuery('#vendor<?php echo $i ; ?>').val() ;
            var demand = jQuery('#demand<?php echo $i ; ?>').val() ;
            var price = jQuery('#price<?php echo $i ; ?>').val() ;
			if(price < max_val ){
				alert('Your Bid price is higher than the current one , Bidding Failed!!') ;
				console.log(price > max_val) ;
			}
			else{
				document.getElementById("winner<?php echo $i ; ?>").innerHTML = '<?php echo $_SESSION['name'] ; ?>' ;
            document.getElementById("winprice<?php echo $i ; ?>").innerHTML = price + ' INR';
            jQuery.ajax({
                url : 'update.php' ,
                type : 'post' ,
                data :{
                    v_id : vendor ,
                    d_id : demand ,
                    bid_price : price
                } ,
                success : function(result){
                    console.log(result) ;
                }
            });
			alert('Bidding Success!!') ;
			}

        }
        var countDownDate<?php echo $i ; ?> = <?php
        echo strtotime("$date $h:$m:$s" ) ?> * 1000;
        var now = <?php echo time() ?> * 1000;
        //var now = <?php echo strtotime('now') ; ?> ;

        // Update the count down every 1 second
        var x<?php echo $i ; ?> = setInterval(function() {
        now = now + 1000;
        // Find the distance between now an the count down date
        var distance = countDownDate<?php echo $i ; ?>  - now;
        // Time calculations for days, hours, minutes and seconds
        var days = Math.floor(distance / (1000 * 60 * 60 * 24));
        var hours = Math.floor((distance % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60));
        var minutes = Math.floor((distance % (1000 * 60 * 60)) / (1000 * 60));
        var seconds = Math.floor((distance % (1000 * 60)) / 1000);
        // Output the result in an element with id="demo"
    document.getElementById('h<?php echo $i ; ?>').innerHTML = hours ;
    document.getElementById('m<?php echo $i ; ?>').innerHTML = minutes ;
            document.getElementById('s<?php echo $i ; ?>').innerHTML = seconds ;
        // If the count down is over, write some text
        if (distance < 0) {
        clearInterval(x<?php echo $i ; ?>);
        document.getElementById('h<?php echo $i ; ?>').style.display= 'none' ;
        document.getElementById('m<?php echo $i ; ?>').style.display= 'none' ;
        document.getElementById('s<?php echo $i ; ?>').style.display= 'none' ;
        document.getElementById("demo<?php echo $i ; ?>").innerHTML = "EXPIRED";
        document.getElementById("demo<?php echo $i ; ?>").style.display = 'block' ;
        var disappear = document.getElementsByClassName('denotes<?php echo $i ;?>') ;
        for(var i = 0 ; i<disappear.length ;i++){
            disappear[i].style.display = 'none' ;
        }
        }

        }, 1000);
    </script>

                    <!-- Auction Item With Timer Ends Here  -->
                    <div class="row">
                        <div class="auction-item">
                            <div class="auction-image">
                                <img src = " <?php
								if(!$link) echo $thumbnail ;
								else echo 'default.png' ;
								 ?> " alt = "Image not found"/>
                            </div>
                            <div class="auction-details">
                                <div class="auction-details-title">
                                    <h5><?php
										if($link)echo $pro_title;
										else echo $title ;
										?> 	 </h5>
                                </div>
                                <?php
									if($link){
								?>
								<div class="bidder">
											<h6>
												<p>Product Link:</p>
												<a href = "<?php echo $link ; ?> "

												style ="margin :2px ; color :orange ;">
													See Product Details
											</a>
											</h6>
								</div>
								<?php } ?>
								<div class="bidder">
											<h6>
												<p>Customer:</p>
												<p><?php echo $customer_name ; ?> </p>
											</h6>
								</div>
                                <div class="auction-details-timebidder">
                                        <div class="bidder">

                                            <h6><p>Current-Bid-Winner : </p><p id = "winner<?php echo $i ; ?>">
                                        <?php
                                                if(!$winning_vendor) echo "N/A" ;
                                                else echo $winning_vendor ;
                                        ?>
                                        </p>
                                        </h6>
                                            <h6><p>Bid Price : </p><p id = "winprice<?php echo $i ; ?>">
                                        <?php
                                                if(!$bid_price) echo "N/A" ;
                                                else echo $bid_price.' INR' ;
                                        ?>
                                        </p>
                                        </h6>
                                        </div>
                                        <div class="auction-timer">
                                        <div class="expired" id = 'demo<?php echo $i ; ?>'></div>
                                            <div class="auction-hours time-boxes" id = 'h<?php echo $i ; ?>' >
                                                00
                                            </div>
                                            <div class="time-denote denotes<?php echo $i; ?>">
                                                h
                                            </div>
                                            <div class="auction-minutes time-boxes" id = 'm<?php echo $i ; ?>' >
                                                00
                                            </div>
                                            <div class="time-denote denotes<?php echo $i; ?>">
                                                m
                                            </div>
                                            <div class="auction-seconds time-boxes" id = 's<?php echo $i ; ?>' >
                                                00
                                            </div>
                                            <div class="time-denote denotes<?php echo $i; ?>">
                                                sec
                                            </div>
                                        </div>
                                </div>
                            </div>
                        </div>
                    </div>

            <?php
    $i++ ;
} ?>
</div>

        <div class="filler"></div>
        <!-- code for the vendor's current bids ends here  -->
	<!-- Jquery -->
    <script src="../js/jquery.min.js"></script>
    <script src="../js/jquery-migrate-3.0.0.js"></script>
	<script src="../js/jquery-ui.min.js"></script>
	<!-- Popper JS -->
	<script src="../js/popper.min.js"></script>
	<!-- Bootstrap JS -->
	<script src="../js/bootstrap.min.js"></script>
	<!-- Color JS -->
	<script src="../js/colors.js"></script>
	<!-- Slicknav JS -->
	<script src="../js/slicknav.min.js"></script>
	<!-- Owl Carousel JS -->
	<script src="../js/owl-carousel.js"></script>
	<!-- Magnific Popup JS -->
	<script src="../js/magnific-popup.js"></script>
	<!-- Waypoints JS -->
	<script src="../js/waypoints.min.js"></script>
	<!-- Countdown JS -->
	<script src="../js/finalcountdown.min.js"></script>
	<!-- Nice Select JS -->
	<script src="../js/nicesellect.js"></script>
	<!-- Flex Slider JS -->
	<script src="../js/flex-slider.js"></script>
	<!-- ScrollUp JS -->
	<script src="../js/scrollup.js"></script>
	<!-- Onepage Nav JS -->
	<script src="../js/onepage-nav.min.js"></script>
	<!-- Easing JS -->
	<script src="../js/easing.js"></script>
	<!-- Active JS -->
	<script src="../js/active.js"></script>
	<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-ka7Sk0Gln4gmtz2MlQnikT1wXgYsOg+OMhuP+IlRH9sENBO0LRn5q+8nbTov4+1p" crossorigin="anonymous"></script>
</body>
</html>
