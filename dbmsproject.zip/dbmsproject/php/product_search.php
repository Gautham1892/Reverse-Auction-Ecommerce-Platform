<!DOCTYPE html>
<html lang="zxx">
<head>
	<!-- Meta Tag -->
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name='copyright' content=''>
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
	<!-- Title Tag  -->
    <title>RevAuc</title>
	<!-- Favicon -->
	<link rel="icon" type="image/png" href="../images/favicon.png">
	<!-- Web Font -->
	<link href="https://fonts.googleapis.com/css?family=Poppins:200i,300,300i,400,400i,500,500i,600,600i,700,700i,800,800i,900,900i&display=swap" rel="stylesheet">

	<!-- StyleSheet -->

	<!-- Bootstrap -->
	<link rel="stylesheet" href="../css/bootstrap.css">
	<!-- Magnific Popup -->
    <link rel="stylesheet" href="../css/magnific-popup.min.css">
	<!-- Font Awesome -->
    <link rel="stylesheet" href="../css/font-awesome.css">
	<!-- Fancybox -->
	<link rel="stylesheet" href="../css/jquery.fancybox.min.css">
	<!-- Themify Icons -->
    <link rel="stylesheet" href="../css/themify-icons.css">
	<!-- Nice Select CSS -->
    <link rel="stylesheet" href="../css/niceselect.css">
	<!-- Animate CSS -->
    <link rel="stylesheet" href="../css/animate.css">
	<!-- Flex Slider CSS -->
    <link rel="stylesheet" href="../css/flex-slider.min.css">
	<!-- Owl Carousel -->
    <link rel="stylesheet" href="../css/owl-carousel.css">
	<!-- Slicknav -->
    <link rel="stylesheet" href="../css/slicknav.min.css">

	<!-- Eshop StyleSheet -->
	<link rel="stylesheet" href="../css/reset.css">
	<link rel="stylesheet" href="../style.css">
    <link rel="stylesheet" href="../css/responsive.css">

	<link href = "../css/main.css?v=<?php echo time(); ?>" rel = "stylesheet">


</head>
<body class="js">
	<?php
		$con = mysqli_connect("localhost" , "root" , "" , "revauc") ;
		if(mysqli_connect_error()){
			echo "Failed to connect to MySQL : ".mysqli_error() ;
			die() ;
		}
		session_start() ;
		if(isset($_POST['link-demand'])){
			$demanding_customer = $_POST['customer'] ;
			$title = $_POST['title'] ;
			$link = $_POST['pro-link'] ;
			$date = $_POST['demand_date'] ;
			$hours = $_POST['hours'] ;
			$minutes = $_POST['minutes'] ;
			$seconds = $_POST['seconds'] ;

			$query = "INSERT INTO demands(cust_id , date , h , m  ,s ,link , pro_title ) VALUES ($demanding_customer , '$date' , $hours , $minutes , $seconds , '$link' , '$title')" ;
			mysqli_query($con , $query) ;
		}

	?>


<?php
		if(isset($_SESSION['login_type']) && $_SESSION['login_type'] == 'V'){
			echo '<script language="javascript">';
     						 echo 'window.location.replace("php/auction_house.php")';
      						echo '</script>';
		}
	?>
	<!-- Header -->
	<header class="header shop">


		<!-- Header Inner -->
		<div class="header-inner">
			<div class="container">
				<div class="cat-nav-head">
					<div class="row">
						<div class="col-lg-3">
							<div class="all-category">
							</div>
						</div>
						<div class="col-lg-9 col-12">
							<div class="menu-area">
								<!-- Main Menu -->
								<nav class="navbar navbar-expand-lg">
									<div class="navbar-collapse">
										<div class="nav-inner">
											<ul class="nav main-menu menu navbar-nav">
                        <li><img src="../images/logo.jfif" alt="RevAuc logo" height="80" width="150"></li>
													<li class="active"><a href="../index.php">Home</a></li>
													<li><a href="#">Products</i></a></li>
													<li><a href="#">Service</a></li>
													<li><a href="#">Category<i class="ti-angle-down"></i></a>
														<ul class="dropdown">
															<li><a href="shop-grid.html">Phones</a></li>
															<li><a href="cart.html">Laptops</a></li>
															<li><a href="checkout.html">Tvs</a></li>
														</ul>
													</li>

													<li><a href="#">Brands<i class="ti-angle-down"></i></a>
														<ul class="dropdown">
															<li><a href="blog-single-sidebar.html">Apple</a></li>
                              <li><a href="blog-single-sidebar.html">Samsung</a></li>
                              <li><a href="blog-single-sidebar.html">OnePlus</a></li>
                              <li><a href="blog-single-sidebar.html">Vivo</a></li>
                              <li><a href="blog-single-sidebar.html">Oppo</a></li>
                              <li><a href="blog-single-sidebar.html">Redmi</a></li>
                              <li><a href="blog-single-sidebar.html">Realme</a></li>
														</ul>
													</li>
													<li><a href="contact.html">Contact Us</a></li>
												</ul>
										</div>
									</div>
								</nav>
								<!--/ End Main Menu -->
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
		<!--/ End Header Inner -->
	</header>
	<!--/ End Header -->
	<!-- Search bar starts here  -->
	<div class="container searchbar">
		<form action="product_search.php" method = 'GET' >
			<div class="input-group">
				<input type="text" class = "form-control search_bar" name = "search_value" placeholder = "Search for products"  id = "search">
				<div class="input-group-btn">
					<button type = "submit" class  = "btn btn-default" id = "search-btn" name = "search-btn" value = "clicked">
						Search
					</button>
				</div>
			</div>
		</form>
	</div>
		<!-- code for the link based demand is here  -->

		<!-- Button trigger modal -->


			<!-- Modal -->
			<div class="modal fade" id="linkBasedDemand" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
			<div class="modal-dialog">
				<div class="modal-content">
				  <div class="demand-modal-content">
					  <h2>CREATE YOUR OWN DEMAND</h2>

					<form action="" method = "post">

					<input type="hidden" name = 'customer' value = <?php if(isset($_SESSION['id']))echo $_SESSION['id'] ; ?> >
					<div class="setTimer-body">
							<input type="text" class = 'form-control' style = "padding:5px; " name = 'title' placeholder = 'Enter the title of the product'>
							<br><br>
							<input type="text" class = 'form-control' style = "padding:5px; "  name = 'pro-link' placeholder = "Paste the link of the product">
					</div>

					<div class="setTimer-body">
							<table class="table-striped">
								<tbody>
									<tr>
										<td><input type="date" name = 'demand_date'></td>
										<td><input type = "number" value = 0 name = "hours"  max = 23 min = 0 /></td>
										<td><input type = "number" value = 0 name = "minutes"  max = 59 min = 0  /></td>
										<td><input type = "number" value = 0 name = "seconds" max = 59 min = 0 /></td>
									</tr>
									<tr>
										<td>Date</td>
										<td>Hours</td>
										<td>Minutes</td>
										<td>Seconds</td>
									</tr>
								</tbody>
								</table>

						</div>
				  </div>
				<div class="modal-footer">
					<button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
					<button type="submit"name='link-demand' value='demanded' class="btn btn-primary" >Raise Demand</button>
					</form>
				</div>
				</div>
			</div>
			</div>
				<div class="link-based-demand">
					<h1>
						Unable to find the product you are searching for ?
						<h6>click the button given below to demand an item that is not in this site </h6>
					</h1>
					<div class="link-based-demand-btn">
					<?php
						if(isset($_SESSION['id'])){
					?>

					<!-- <button type="button" class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#linkBasedDemand">Demand Now</button> -->
						<button type = "button" data-bs-toggle="modal" data-bs-target="#linkBasedDemand" >Demand Now</button>

					<?php }
					else{
					?>
							<h5><a href="../index.php">Go to homepage and Login</a></h5>
					<?php
					} ?>
					</div>
				</div>
		<!-- code for the link based demand is ends here  -->
		<!-- Product Style -->
		<section class="product-area shop-sidebar shop section">
			<div class="container">
				<div class="row">
					<div class="col-lg-3 col-md-4 col-12">
						<div class="shop-sidebar">
								<!-- Single Widget -->
								<div class="single-widget category">
									<h3 class="title">Categories</h3>
									<ul class="categor-list">
										<li><a href="#">Phones</a></li>
										<li><a href="#">TVs</a></li>
									</ul>
								</div>
								<!--/ End Single Widget -->
								<!-- Single Widget -->
								<div class="single-widget recent-post">
									<h3 class="title">Recent post</h3>

							<?php
								$query = "SELECT * FROM product ORDER BY sno DESC LIMIT 3" ;
								$res = mysqli_query($con , $query) ;
								while($row = mysqli_fetch_array($res)){
							?>
									<!-- Single Post -->
									<div class="single-post first">
										<div class="image">
											<img src="<?php echo $row['image1'] ;?>" alt="#">
										</div>
										<div class="content">
											<h5><a href="det.php?pro=<?php echo $row['p_id'] ; ?>"><?php echo $row['title'] ; ?></a></h5>
											<ul class="reviews">
												<li class="yellow"><i class="ti-star"></i></li>
												<li class="yellow"><i class="ti-star"></i></li>
												<li class="yellow"><i class="ti-star"></i></li>
												<li><i class="ti-star"></i></li>
												<li><i class="ti-star"></i></li>
											</ul>
										</div>
									</div>
									<!-- End Single Post -->
									<?php
									}
								?>
								</div>
								<!--/ End Single Widget -->

						</div>
					</div>
					<div class="col-lg-9 col-md-8 col-12">
					<div class="row">
				<?php

				if(isset($_GET['search-btn']) && $_GET['search-btn'] == 'clicked'){
					$keyword = mysqli_real_escape_string($con,$_GET["search_value"]);
					$query = "SELECT * FROM product WHERE title LIKE '%$keyword%'" ;
				}
				else{
					$query = "SELECT * FROM product" ;

				}
				$res = mysqli_query($con , $query) ;
					$counter =  0 ;
				if(mysqli_num_rows($res) == 0){
						echo "No results found!!<br> " ;
				}
				else{
					while($row = mysqli_fetch_array($res)){
					?>

							<div class="col-lg-4 col-md-6 col-12">
									<div class="single-product">
										<div class="product-img">
											<a href="product-details.html">
												<img class="default-img" src="<?php echo $row['image1'] ; ?>" alt="#">
												<img class="hover-img" src="<?php echo $row['image2'] ; ?>" alt="#">
											</a>
											<div class="button-head">
												<div class="product-action">
													<a data-toggle="modal" data-target="#exampleModal" title="Quick View" href="det.php?pro=<?php echo $row['p_id'] ; ?>"><i class=" ti-eye"></i><span>View Details</span></a>
												</div>
												<div class="product-action-2">
													<!-- <form action="det.php"  method = "GET">
											<input type = "hidden" name = "pro" value = "<?php //echo $row['p_id'] ; ?>">
											<button type = "submit" class = "shop-btn">Add to cart </button>
												</form> -->
												<a data-toggle="modal" data-target="#exampleModal" title="Quick View" href="det.php?pro=<?php echo $row['p_id'] ; ?>">View Details</a>
												</div>
											</div>
										</div>
										<div class="product-content">
											<h3><a href="product-details.html">
												<?php echo $row['title'] ; ?>
											</a></h3>
											<!--<div class="product-price">
												<span>$29.00</span>
											</div>-->
										</div>
									</div>
								</div>

				<?php
					$counter++ ;
					}
				}
				?>
			</div>
			</div>
		</section>
		<!--/ End Product Style 1  -->

		<!-- Start Shop Newsletter  -->
		<section class="shop-newsletter section">
			<div class="container">
				<div class="inner-top">
					<div class="row">
						<div class="col-lg-8 offset-lg-2 col-12">
							<!-- Start Newsletter Inner -->
							<div class="inner">
								<h4>Newsletter</h4>
								<p> Subscribe to our newsletter and get <span>10%</span> off your first purchase</p>
								<form action="mail/mail.php" method="get" target="_blank" class="newsletter-inner">
									<input name="EMAIL" placeholder="Your email address" required="" type="email">
									<button class="btn">Subscribe</button>
								</form>
							</div>
							<!-- End Newsletter Inner -->
						</div>
					</div>
				</div>
			</div>
		</section>
		<!-- End Shop Newsletter -->



		<!-- Modal -->
			<div class="modal fade" id="exampleModal" tabindex="-1" role="dialog">
				<div class="modal-dialog" role="document">
					<div class="modal-content">
						<div class="modal-header">
							<button type="button" class="close" data-dismiss="modal" aria-label="Close"><span class="ti-close" aria-hidden="true"></span></button>
						</div>
						<div class="modal-body">
							<div class="row no-gutters">
								<div class="col-lg-6 col-md-12 col-sm-12 col-xs-12">
									<!-- Product Slider -->
										<div class="product-gallery">
											<div class="quickview-slider-active">
												<div class="single-slider">
													<img src="https://via.placeholder.com/569x528" alt="#">
												</div>
												<div class="single-slider">
													<img src="https://via.placeholder.com/569x528" alt="#">
												</div>
												<div class="single-slider">
													<img src="https://via.placeholder.com/569x528" alt="#">
												</div>
												<div class="single-slider">
													<img src="https://via.placeholder.com/569x528" alt="#">
												</div>
											</div>
										</div>
									<!-- End Product slider -->
								</div>
								<div class="col-lg-6 col-md-12 col-sm-12 col-xs-12">
									<div class="quickview-content">
										<h2>Flared Shift Dress</h2>
										<div class="quickview-ratting-review">
											<div class="quickview-ratting-wrap">
												<div class="quickview-ratting">
													<i class="yellow fa fa-star"></i>
													<i class="yellow fa fa-star"></i>
													<i class="yellow fa fa-star"></i>
													<i class="yellow fa fa-star"></i>
													<i class="fa fa-star"></i>
												</div>
												<a href="#"> (1 customer review)</a>
											</div>
											<div class="quickview-stock">
												<span><i class="fa fa-check-circle-o"></i> in stock</span>
											</div>
										</div>
										<h3>$29.00</h3>
										<div class="quickview-peragraph">
											<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Mollitia iste laborum ad impedit pariatur esse optio tempora sint ullam autem deleniti nam in quos qui nemo ipsum numquam.</p>
										</div>
										<div class="size">
											<div class="row">
												<div class="col-lg-6 col-12">
													<h5 class="title">Size</h5>
													<select>
														<option selected="selected">s</option>
														<option>m</option>
														<option>l</option>
														<option>xl</option>
													</select>
												</div>
												<div class="col-lg-6 col-12">
													<h5 class="title">Color</h5>
													<select>
														<option selected="selected">orange</option>
														<option>purple</option>
														<option>black</option>
														<option>pink</option>
													</select>
												</div>
											</div>
										</div>
										<div class="quantity">
											<!-- Input Order -->
											<div class="input-group">
												<div class="button minus">
													<button type="button" class="btn btn-primary btn-number" disabled="disabled" data-type="minus" data-field="quant[1]">
														<i class="ti-minus"></i>
													</button>
												</div>
												<input type="text" name="quant[1]" class="input-number"  data-min="1" data-max="1000" value="1">
												<div class="button plus">
													<button type="button" class="btn btn-primary btn-number" data-type="plus" data-field="quant[1]">
														<i class="ti-plus"></i>
													</button>
												</div>
											</div>
											<!--/ End Input Order -->
										</div>
										<div class="add-to-cart">
											<a href="#" class="btn">Add to cart</a>
											<a href="#" class="btn min"><i class="ti-heart"></i></a>
											<a href="#" class="btn min"><i class="fa fa-compress"></i></a>
										</div>
										<div class="default-social">
											<h4 class="share-now">Share:</h4>
											<ul>
												<li><a class="facebook" href="#"><i class="fa fa-facebook"></i></a></li>
												<li><a class="twitter" href="#"><i class="fa fa-twitter"></i></a></li>
												<li><a class="youtube" href="#"><i class="fa fa-pinterest-p"></i></a></li>
												<li><a class="dribbble" href="#"><i class="fa fa-google-plus"></i></a></li>
											</ul>
										</div>
									</div>
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
			<!-- Modal end -->
<!-- Start Footer Area -->
	<footer class="footer">
		<!-- Footer Top -->
		<div class="footer-top section">
			<div class="container">
				<div class="row">
					<div class="col-lg-5 col-md-6 col-12">
						<!-- Single Widget -->
						<div class="single-footer about">
							<div class="logo">
								<a href="index.html"><img src="images/brandlogo.png" alt="#"></a>
							</div>
							<p class="text">This page was created as a project by <br>Gautham<br>
							Sourav <br> Jayenth.</p>
							<p class="call">Got Question? Call us 24/7<span><a href="tel:123456789">123 456 789</a></span></p>
						</div>
						<!-- End Single Widget -->
					</div>
					<div class="col-lg-2 col-md-6 col-12">
						<!-- Single Widget -->
						<div class="single-footer links">
							<h4>Information</h4>
							<ul>
								<li><a href="#">About Us</a></li>
								<li><a href="#">Faq</a></li>
								<li><a href="#">Terms & Conditions</a></li>
								<li><a href="#">Contact Us</a></li>
								<li><a href="#">Help</a></li>
							</ul>
						</div>
						<!-- End Single Widget -->
					</div>
					<div class="col-lg-2 col-md-6 col-12">
						<!-- Single Widget -->
						<div class="single-footer links">
							<h4>Customer Service</h4>
							<ul>
								<li><a href="#">Payment Methods</a></li>
								<li><a href="#">Money-back</a></li>
								<li><a href="#">Returns</a></li>
								<li><a href="#">Shipping</a></li>
								<li><a href="#">Privacy Policy</a></li>
							</ul>
						</div>
						<!-- End Single Widget -->
					</div>
					<div class="col-lg-3 col-md-6 col-12">
						<!-- Single Widget -->
						<div class="single-footer social">
							<h4>Get In T0uch</h4>
							<!-- Single Widget -->
							<div class="contact">
								<ul>
									<li>M/1, pushkar apartments</li>
									<li>Chennai-80</li>
									<li>gauthammass2@gmail.com</li>
									<li>1234567891</li>
								</ul>
							</div>
							<!-- End Single Widget -->
							<ul>
								<li><a href="#"><i class="ti-facebook"></i></a></li>
								<li><a href="#"><i class="ti-twitter"></i></a></li>
								<li><a href="#"><i class="ti-flickr"></i></a></li>
								<li><a href="#"><i class="ti-instagram"></i></a></li>
							</ul>
						</div>
						<!-- End Single Widget -->
					</div>
				</div>
			</div>
		</div>
		<!-- End Footer Top -->
		<div class="copyright">
			<div class="container">
				<div class="inner">
					<div class="row">
						<div class="col-lg-6 col-12">
							<div class="left">
								<p>Copyright © 2022 <a href="http://www.wpthemesgrid.com" target="_blank">dbms project</a>  -  All Rights Reserved.</p>
							</div>
						</div>
						<div class="col-lg-6 col-12">
							<div class="right">
								<img src="images/payments.png" alt="#">
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
	</footer>
	<!-- /End Footer Area -->

	<!-- Jquery -->
    <script src="js/jquery.min.js"></script>
    <script src="js/jquery-migrate-3.0.0.js"></script>
	<script src="js/jquery-ui.min.js"></script>
	<!-- Popper JS -->
	<script src="js/popper.min.js"></script>
	<!-- Bootstrap JS -->
	<script src="js/bootstrap.min.js"></script>
	<!-- Color JS -->
	<script src="js/colors.js"></script>
	<!-- Slicknav JS -->
	<script src="js/slicknav.min.js"></script>
	<!-- Owl Carousel JS -->
	<script src="js/owl-carousel.js"></script>
	<!-- Magnific Popup JS -->
	<script src="js/magnific-popup.js"></script>
	<!-- Waypoints JS -->
	<script src="js/waypoints.min.js"></script>
	<!-- Countdown JS -->
	<script src="js/finalcountdown.min.js"></script>
	<!-- Nice Select JS -->
	<script src="js/nicesellect.js"></script>
	<!-- Flex Slider JS -->
	<script src="js/flex-slider.js"></script>
	<!-- ScrollUp JS -->
	<script src="js/scrollup.js"></script>
	<!-- Onepage Nav JS -->
	<script src="js/onepage-nav.min.js"></script>
	<!-- Easing JS -->
	<script src="js/easing.js"></script>
	<!-- Active JS -->
	<script src="js/active.js"></script>
	<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-ka7Sk0Gln4gmtz2MlQnikT1wXgYsOg+OMhuP+IlRH9sENBO0LRn5q+8nbTov4+1p" crossorigin="anonymous"></script>
</body>
</html>
