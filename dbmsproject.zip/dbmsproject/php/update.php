<?php
    $con = mysqli_connect("localhost" , "root" , "" , "revauc") ; 
    if(mysqli_connect_error()){
        echo "Failed to connect to MySQL : ".mysqli_error() ; 
        die() ; 
    }
    session_start() ; 

    $bidder = $_POST['v_id'] ; 
    $price = $_POST['bid_price'] ;
    $demand = $_POST['d_id'] ; 
    
    $query = "UPDATE demands SET bid_price = $price , lowest_bidder = $bidder  WHERE d_id = $demand" ; 
    $res = mysqli_query($con , $query) ; 
    if($res) echo "data updated" ; 
    else{
        echo 'no update <br>' ; 
        echo $query ; 
        echo '<br>' ; 
        echo $con->error ; 
    }
    // $query = "UPDATE demands SET lowest_bidder = $bidder WHERE d_id = $demand" ; 
    // mysqli_query($con , $query) ; 

    // $query = "SELECT * FROM demands WHERE d_id = $demand" ; 
    // $res = mysqli_query($con , $query) ;  
    // while($row = mysqli_fetch_array($res)){
    //     echo 'Bidder:'.$row['lowest_bidder'].'<br>';
    //     echo 'price:'.$row['bid_price'].'<br>';
    // }
?>
